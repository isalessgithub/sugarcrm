       
  <?php
         $app_filter = '';
        $month_three = date("Y-m-", strtotime("-3 months")).'01';
 $week_start = date("Y-m-d H:i:s",strtotime('monday this week'));
        if($range == 'all')
        {
         $app_filter = " ";
     }
          else if($range == 'week')
     {
         $app_filter = "AND (atc_appointments.appointment_date >= Date('".$week_start."'))";
     }
     else if($range == 'this')
     {
         $app_filter = "AND (Month(atc_appointments.appointment_date) = Month(curdate()) AND Year(atc_appointments.appointment_date) = Year(curdate()))";
     }
     else if ($range == 'three')
     {
         $app_filter = "AND (atc_appointments.appointment_date >= Date('".$month_three."'))
         AND (atc_appointments.appointment_date <= Last_Day(curdate()))";
     }
     else if ($range == 'last')
     {
         $app_filter = "AND (Month(atc_appointments.appointment_date) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(atc_appointments.appointment_date) = Year(Date_Sub(curdate(),interval 1 month)))";
     }
     else
     {
         $app_filter = "AND (atc_appointments.appointment_date > date('".$sqlStart."') or '' = '".$sqlStart."')
         AND (atc_appointments.appointment_date <= date('".$sqlEnd."') or '' = '".$sqlEnd."')";
     }



     $app_camp_query = "SELECT cstm.appointment_result_c as apr,
     SUM(CASE WHEN atc_appointments.opportunity_amount = 'No_Result' THEN 1 ELSE 0 END) AS nr,
     SUM(CASE WHEN atc_appointments.opportunity_amount = '35' THEN 1 ELSE 0 END) AS n35,
     SUM(CASE WHEN atc_appointments.opportunity_amount = '75' THEN 1 ELSE 0 END) AS n75,
     SUM(CASE WHEN atc_appointments.opportunity_amount = '150' THEN 1 ELSE 0 END) AS n150,
     SUM(CASE WHEN atc_appointments.opportunity_amount = '150_Plus' THEN 1 ELSE 0 END) AS n150_Plus,
     SUM(CASE WHEN atc_appointments.opportunity_amount = '400' THEN 1 ELSE 0 END) AS n400,
     SUM(CASE WHEN atc_appointments.opportunity_amount = '1m' THEN 1 ELSE 0 END) AS n1m
     FROM atc_appointments INNER JOIN atc_isscampaigns_atc_appointments_c ca
     ON ca.atc_isscampaigns_atc_appointmentsatc_appointments_idb = atc_appointments.id
     INNER JOIN atc_clientsalesreps_atc_appointments_c sa
     ON sa.atc_clientsalesreps_atc_appointmentsatc_appointments_idb = atc_appointments.id
     LEFT JOIN atc_appointments_cstm cstm
     ON cstm.id_c = atc_appointments.id
     WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".implode("','",$campaign)."')
     AND atc_appointments.deleted = 0
     and ca.deleted = 0
     and sa.deleted = 0
     AND (appointment_status = 'Attended' OR appointment_status ='Attended_Policy' OR appointment_status = 'Confirmed')
     AND cstm.appointment_result_c IN('NoResult','SixMonths','TwelveMonths','Longer') ".$salesrepfilter.$app_filter." GROUP BY cstm.appointment_result_c
     ORDER BY cstm.appointment_result_c;";

    $noResult = Array();$noResult['No_Result'] = 0;$noResult['35'] = 0;$noResult['75'] = 0;$noResult['150']=0;$noResult['150_Plus']=0;$noResult['400']=0;$noResult['1m']=0;
    $SixMonths = Array();$SixMonths['No_Result'] = 0;$SixMonths['35'] = 0;$SixMonths['75'] = 0;$SixMonths['150']=0;$SixMonths['150_Plus']=0;$SixMonths['400']=0;$SixMonths['1m']=0;
    $TwelveMonths = Array();$TwelveMonths['No_Result'] = 0;$TwelveMonths['35'] = 0;$TwelveMonths['75'] = 0;$TwelveMonths['150']=0;$TwelveMonths['150_Plus']=0;$TwelveMonths['400']=0;$TwelveMonths['1m']=0;
    $Longer = Array();$Longer['No_Result'] = 0;$Longer['35'] = 0;$Longer['75'] = 0;$Longer['150']=0;$Longer['150_Plus']=0;$Longer['400']=0;$Longer['1m']=0;
/*
$logfile = 'portal_log.txt';
// Open the file to get existing content
$currentlog = file_get_contents($logfile);
// Append a new person to the file
$currentlog .= $app_camp_query."\n";
// Write the contents back to the file
file_put_contents($logfile, $currentlog);

*/
    $app_camp_result = mysqli_query($con,$app_camp_query);
    while ($row = mysqli_fetch_array($app_camp_result))
     {
       if($row['apr'] == 'NoResult'){$noResult['No_Result'] = $row['nr'];$noResult['35']=$row['n35'];$noResult['75']=$row['n75'];$noResult['150']=$row['n150'];$noResult['150_Plus']=$row['n150_Plus'];$noResult['400']=$row['n400'];$noResult['1m']=$row['n1m'];}
       if($row['apr'] == 'SixMonths'){$SixMonths['No_Result'] = $row['nr'];$SixMonths['35']=$row['n35'];$SixMonths['75']=$row['n75'];$SixMonths['150']=$row['n150'];$SixMonths['150_Plus']=$row['n150_Plus'];$SixMonths['400']=$row['n400'];$SixMonths['1m']=$row['n1m'];}
       if($row['apr'] == 'TwelveMonths'){$TwelveMonths['No_Result'] = $row['nr'];$TwelveMonths['35']=$row['n35'];$TwelveMonths['75']=$row['n75'];$TwelveMonths['150']=$row['n150'];$TwelveMonths['150_Plus']=$row['n150_Plus'];$TwelveMonths['400']=$row['n400'];$TwelveMonths['1m']=$row['n1m'];}
       if($row['apr'] == 'Longer'){$Longer['No_Result'] = $row['nr'];$Longer['35']=$row['n35'];$Longer['75']=$row['n75'];$Longer['150']=$row['n150'];$Longer['150_Plus']=$row['n150_Plus'];$Longer['400']=$row['n400'];$Longer['1m']=$row['n1m'];}
     }

/*
     $maxValueTotals = Array();
     $maxValueTotals['35'] = $SixMonths['35'] + $TwelveMonths['35'] + $Longer['35'];
     $maxValueTotals['75'] = $SixMonths['75'] + $TwelveMonths['75'] + $Longer['75'];
     $maxValueTotals['150'] = $SixMonths['150'] + $TwelveMonths['150'] + $Longer['150'];
     $maxValueTotals['150_Plus'] = $SixMonths['150_Plus'] + $TwelveMonths['150_Plus'] + $Longer['150_Plus'];
*/
/*
$logfile = 'portal_log.txt';
// Open the file to get existing content
$currentlog = file_get_contents($logfile);
// Append a new person to the file
$currentlog .= $app_camp_query."\n";
// Write the contents back to the file
file_put_contents($logfile, $currentlog);

*/
 ?>
       <table width="100%" border="1" style="background: url(images/white-bg.png);" class="table table-striped">
        <thead><tr>
            <th colspan="14" style="text-align: center;">
                Estimated Opportunity Value
            </th>
            <!--th colspan="8" style="text-align: center;">
                Number of Appointments by Opportunity Value and Timeline
            </th-->
        </tr></thead>
        <tr>
            <td colspan="14" width="100%">
                <div id="ChartMaxPotentialLine"style="width: 875px; height: 300px; background: url(images/white-bg.png);"></div>
            </td>
            <!--td colspan="8" width="50%">
                <div id="campappsbysizeandtime"style="width: 475px; height: 300px; background: url(images/white-bg.png);"></div>
            </td-->
        </tr>
        <tr>
            
            <td colspan=2>
                Time
            </td>
             <td>
                Qty
            </td>
            <td>
                Cumulative Value
            </td>
            <td>
                Total Count
            </td>
            <!--td></td>
            <td>
                No Result
            </td>
            <td>
                0-35k
            </td>
            <td>
                35-75k
            </td>
            <td>
                75k-150k
            </td>
            <td>
                150k - 400k
            </td>
            <td>
                400k - 1m
            </td>
            <td>
                1m +
            </td-->
        </tr>
        <tr>
            <td colspan=2>
                No Timeline
            </td>
            <td>
                <?php echo ($noResult['No_Result'] + $noResult['35'] + $noResult['75'] + $noResult['150'] + $noResult['150_Plus'] + $noResult['400'] + $noResult['1m']); ?>
            </td>
            <td>
                <?php echo ($noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*200000 + $noResult['400']*400000 + $noResult['1m']*1000000); ?>
            </td>
          
            <td>
                <?php echo ($noResult['No_Result'] + $noResult['35'] + $noResult['75'] + $noResult['150'] + $noResult['150_Plus'] + $noResult['400'] + $noResult['1m']); ?>
            </td>
            <!--td>No Timeline</td>
            <td>
                <?php echo $noResult['No_Result']; ?>
            </td>
            <td>
                <?php echo $noResult['35']; ?>
            </td>
            <td>
                <?php echo $noResult['75']; ?>
            </td>
            <td>
               <?php echo $noResult['150']; ?>
            </td>
            <td>
               <?php echo $noResult['150_Plus']; ?>
            </td>
            <td>
               <?php echo $noResult['400']; ?>
            </td>
            <td>
               <?php echo $noResult['1m']; ?>
            </td-->
        </tr>
        <tr>
            <td colspan=2>
                Within 6 Months
            </td>
            <td>
                <?php echo ($SixMonths['No_Result'] + $SixMonths['35'] + $SixMonths['75'] + $SixMonths['150'] + $SixMonths['150_Plus'] + $SixMonths['400'] + $SixMonths['1m']); ?>
            </td>
            <td>
                <?php echo (
                    $SixMonths['No_Result']*0 + $SixMonths['35']*17500+ $SixMonths['75']*55000 + $SixMonths['150']*112500 + $SixMonths['150_Plus']*200000 + $SixMonths['400']*400000 + $SixMonths['1m']*1000000 + 
                    $noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*200000 + $noResult['400']*400000 + $noResult['1m']*1000000); ?>
            </td>
          
            <td>
                <?php echo ($SixMonths['No_Result'] + $SixMonths['35'] + $SixMonths['75'] + $SixMonths['150'] + $SixMonths['150_Plus'] + $SixMonths['400'] + $SixMonths['1m']); ?>
            </td>
            <!--td>Within 6 Months</td>
            <td>
                <?php echo $SixMonths['No_Result']; ?>
            </td>
            <td>
                <?php echo $SixMonths['35']; ?>
            </td>
            <td>
                <?php echo $SixMonths['75']; ?>
            </td>
            <td>
               <?php echo $SixMonths['150']; ?>
            </td>
            <td>
               <?php echo $SixMonths['150_Plus']; ?>
            </td>
            <td>
               <?php echo $SixMonths['400']; ?>
            </td>
            <td>
               <?php echo $SixMonths['1m']; ?>
            </td-->
        </tr>
        <tr>
            <td colspan=2>
                Within 6 to 12 Months
            </td>
               <td>
                <?php echo ($TwelveMonths['No_Result'] + $TwelveMonths['35'] + $TwelveMonths['75'] + $TwelveMonths['150'] + $TwelveMonths['150_Plus'] + $TwelveMonths['400'] + $TwelveMonths['1m']); ?>
            </td>
            <td>
                <?php echo (
                $TwelveMonths['No_Result']*0 + $TwelveMonths['35']*17500+ $TwelveMonths['75']*55000 + $TwelveMonths['150']*112500 + $TwelveMonths['150_Plus']*200000 + $TwelveMonths['400']*400000 + $TwelveMonths['1m']*1000000 + 
                $SixMonths['No_Result']*0 + $SixMonths['35']*17500+ $SixMonths['75']*55000 + $SixMonths['150']*112500 + $SixMonths['150_Plus']*200000 + $SixMonths['400']*400000 + $SixMonths['1m']*1000000 + 
                $noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*200000 + $noResult['400']*400000 + $noResult['1m']*1000000); ?>
            </td>
         
            <td>
                <?php echo (
                $noResult['No_Result'] + $noResult['35'] + $noResult['75'] + $noResult['150'] + $noResult['150_Plus'] + $noResult['400'] + $noResult['1m'] +
                $SixMonths['No_Result'] + $SixMonths['35'] + $SixMonths['75'] + $SixMonths['150'] + $SixMonths['150_Plus'] + $SixMonths['400'] + $SixMonths['1m'] +
                $TwelveMonths['No_Result'] + $TwelveMonths['35'] + $TwelveMonths['75'] + $TwelveMonths['150'] + $TwelveMonths['150_Plus'] + $TwelveMonths['400'] + $TwelveMonths['1m']); ?>

            </td>
            <!--td>Within 6 to 12 Months</td>
            <td>
                <?php echo $TwelveMonths['No_Result']; ?>
            </td>
            <td>
                <?php echo $TwelveMonths['35']; ?>
            </td>
            <td>
                <?php echo $TwelveMonths['75']; ?>
            </td>
            <td>
               <?php echo $TwelveMonths['150']; ?>
            </td>
            <td>
               <?php echo $TwelveMonths['150_Plus']; ?>
            </td>
            <td>
               <?php echo $TwelveMonths['400']; ?>
            </td>
            <td>
               <?php echo $TwelveMonths['1m']; ?>
            </td-->
        </tr>
        <tr>
            <td colspan=2>
                Greater than 12 Months
                </td>
             <td>
                <?php echo ($Longer['No_Result'] + $Longer['35'] + $Longer['75'] + $Longer['150'] + $Longer['150_Plus'] + $Longer['400'] + $Longer['1m']); ?>
            </td>
            <td>
                <?php echo (
                $Longer['No_Result']*0 + $Longer['35']*17500+ $Longer['75']*55000 + $Longer['150']*112500 + $Longer['150_Plus']*200000 + $Longer['400'] + $Longer['1m'] +
                $TwelveMonths['No_Result']*0 + $TwelveMonths['35']*17500+ $TwelveMonths['75']*55000 + $TwelveMonths['150']*112500 + $TwelveMonths['150_Plus']*200000 + $TwelveMonths['400']*400000 + $TwelveMonths['1m']*1000000 +
                $SixMonths['No_Result']*0 + $SixMonths['35']*17500+ $SixMonths['75']*55000 + $SixMonths['150']*112500 + $SixMonths['150_Plus']*200000 + $SixMonths['400']*400000 + $SixMonths['1m']*1000000 +
                $noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*200000 + $noResult['400']*400000 + $noResult['1m']*1000000); ?>
            </td>
      
            <td>
                <?php echo (
                $noResult['No_Result'] + $noResult['35'] + $noResult['75'] + $noResult['150'] + $noResult['150_Plus'] + $noResult['400'] + $noResult['1m'] +
                $SixMonths['No_Result'] + $SixMonths['35'] + $SixMonths['75'] + $SixMonths['150'] + $SixMonths['150_Plus'] + $SixMonths['400'] + $SixMonths['1m'] +
                $TwelveMonths['No_Result'] + $TwelveMonths['35'] + $TwelveMonths['75'] + $TwelveMonths['150'] + $TwelveMonths['150_Plus'] + $TwelveMonths['400'] + $TwelveMonths['1m'] +
                $Longer['No_Result'] + $Longer['35'] + $Longer['75'] + $Longer['150'] + $Longer['150_Plus'] + $Longer['400'] + $Longer['1m']); ?>

            </td>
            <!--td>Greater than 12 Months</td>
            <td>
                <?php echo $Longer['No_Result'];?>
            </td>
            <td>
                <?php echo $Longer['35'];?>
            </td>
            <td>
                <?php echo $Longer['75'];?>
            </td>
            <td>
               <?php echo $Longer['150'];?>
            </td>
            <td>
               <?php echo $Longer['150_Plus'];?>
            </td>
            <td>
               <?php echo $Longer['400']; ?>
            </td>
            <td>
               <?php echo $Longer['1m']; ?>
            </td-->
        </tr>
    </table>
    <table width="100%" border="1" style="background: url(images/white-bg.png);" class="table table-striped">
        <thead><tr>
            <th colspan="4" style="text-align: center;">
                Appointments Held
            </th>
        </tr></thead>
        <tr>
            <td colspan="2" width="50%">
                <div id="ChartHeldPie"style="width: 475px; height: 300px; background: url(images/white-bg.png);"></div>
            </td>
            <td colspan="2" width="50%">
                <div id="ChartAppHeld"style="width: 475px; height: 300px; background: url(images/white-bg.png);"></div>
            </td>
        </tr>
        <tr>
            <td>
                Total Held
            </td>
            <td>
                <?php echo $num_held; ?>
            </td>
            <td>
                Monthly Average
            </td>
            <td>
                <?php echo round($num_held_avg,1); ?>
            </td>
        </tr>
        <tr>
            <td>
                Current Month
            </td>
            <td>
                <?php echo $num_held_month; ?>
            </td>
            <td>
                Previous Month
            </td>
            <td>
                <?php echo $num_held_last; ?>
            </td>
        </tr>
    </table>
    <table width="100%" border="1" style="background: url(images/white-bg.png);" class="table table-striped">
        <thead><tr>
            <th colspan="4" style="text-align: center;">
                Appointments Set by Max Value
            </th>
        </tr></thead>
        <tr>
            <td colspan="2" width="50%">
                <div id="appsbymaxvaluepie"style="width: 475px; height: 300px; background: url(images/white-bg.png);"></div>
            </td>
            <td colspan="2" width="50%">
                <div id="appsbymaxvaluebar"style="width: 475px; height: 300px; background: url(images/white-bg.png);"></div>
            </td>
        </tr>
        <tr>
            <td>Deal Size
            </td>
            <td>Appointments Held
            </td>
            <td>Deal Size
            </td>
            <td>Appointments Held
            </td>
        </tr>
        <tr>
            <td>No Result
            </td>
            <td><?php echo($noResult['No_Result'] + $SixMonths['No_Result'] + $TwelveMonths['No_Result'] + $Longer['No_Result']); ?>
            </td>
            <td>No Result
            </td>
            <td><?php echo($noResult['No_Result'] + $SixMonths['No_Result'] + $TwelveMonths['No_Result'] + $Longer['No_Result']); ?>
            </td>
        </tr>
        <tr>
            <td>0-35K
            </td>
            <td><?php echo($noResult['35'] + $SixMonths['35'] + $TwelveMonths['35'] + $Longer['35']); ?>
            </td>
            <td>0-35K
            </td>
            <td><?php echo($noResult['35'] + $SixMonths['35'] + $TwelveMonths['35'] + $Longer['35']); ?>
            </td>
        </tr>
        <tr>
            <td>35-75K
            </td>
            <td><?php echo($noResult['75'] + $SixMonths['75'] + $TwelveMonths['75'] + $Longer['75']); ?>
            </td>
            <td>35-75K
            </td>
            <td><?php echo($noResult['75'] +$SixMonths['75'] + $TwelveMonths['75'] + $Longer['75']); ?>
            </td>
        </tr>
        <tr>
            <td>75-150K
            </td>
            <td><?php echo($noResult['150'] + $SixMonths['150'] + $TwelveMonths['150'] + $Longer['150']); ?>
            </td>
            <td>75-150K
            </td>
            <td><?php echo($noResult['150'] + $SixMonths['150'] + $TwelveMonths['150'] + $Longer['150']); ?>
            </td>
        </tr>
        <tr>
            <td>150K - 400K
            </td>
            <td><?php echo($noResult['150_Plus'] + $SixMonths['150_Plus'] + $TwelveMonths['150_Plus'] + $Longer['150_Plus']); ?>
            </td>
            <td>150K+
            </td>
            <td><?php echo($noResult['150_Plus'] + $SixMonths['150_Plus'] + $TwelveMonths['150_Plus'] + $Longer['150_Plus']); ?>
            </td>
        </tr>
        <tr>
            <td>400K - 1 M
            </td>
            <td><?php echo($noResult['400'] + $SixMonths['400'] + $TwelveMonths['400'] + $Longer['400']); ?>
            </td>
            <td>150K+
            </td>
            <td><?php echo($noResult['400'] + $SixMonths['400'] + $TwelveMonths['400'] + $Longer['400']); ?>
            </td>
        </tr>
        <tr>
            <td>1M +
            </td>
            <td><?php echo($noResult['1m'] + $SixMonths['1m'] + $TwelveMonths['1m'] + $Longer['1m']); ?>
            </td>
            <td>150K+
            </td>
            <td><?php echo($noResult['1m'] + $SixMonths['1m'] + $TwelveMonths['1m'] + $Longer['1m']); ?>
            </td>
        </tr>
    </table>
       <script type='text/javascript'>//<![CDATA[ 
        $(function () {
            $('#ChartHeldPie').highcharts({
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false
                },
                title: {
                    text: ''
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            color: '#000000',
                            connectorColor: '#000000',
                        format: '<b>{point.name}</b>'//: {point.percentage:.1f} %'
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Activity',
                data: [
                <?php 
                if ($app_cht_results[0] > 0) {echo "['No Timeline', ".$app_cht_results[0]."],";}
                if ($app_cht_results[1] > 0) {echo "['Within 6 Months', ".$app_cht_results[1]."],";}
                if ($app_cht_results[2] > 0) {echo "['6-12 Months', ".$app_cht_results[2]."],";}
                if ($app_cht_results[3] > 0) {echo "['Greater than 12 Months', ".$app_cht_results[3]."],";} 
                ?>
                ]
            }],
        });
});
    //]]>
</script>
    <script type='text/javascript'>//<![CDATA[ 
        $(function () {
            $('#ChartAppHeld').highcharts({
                chart: {
                    type: 'bar'
                },
                title: {
                    text: ''
                },
                xAxis: {
                    categories: ['No Timeline','Within 6 Months','6-12 Months','Greater than 12 Months'],
                //title: {
                //    text: 'Fruit Types'
                //}
            },
            series: [{
                name: 'Appointment Result',
                data: [<?php echo $app_cht_results[0].",".$app_cht_results[1].",".$app_cht_results[2].",".$app_cht_results[3]; ?>]
            }],
            legend: {
                enabled: false
            }

        });
        });
    //]]>  
</script>
<script type="text/javascript">
$(function () {
        $('#ChartMaxPotentialLine').highcharts({
            title: {
                text: '',
                x: -20 //center
            },
            subtitle: {
                text: '',
                x: -20
            },
            xAxis: {
                categories: ['No Timeline','Within 6 Months', '6-12 Months', 'Greater than 12 Months']
            },
            yAxis: {
                labels: {
                formatter: function() {
                  if ( this.value > 1000 && this.value < 1000000 ) return "$" + Highcharts.numberFormat( this.value/1000, 0) + "K";  // maybe only switch if > 1000
                  else if ( this.value >= 1000000 ) return "$" + Highcharts.numberFormat( this.value/1000000, 1) + "M";  // maybe only switch if > 1000
                  return Highcharts.numberFormat(this.value,0);
                }                
            },
                title: {
                    text: 'Total Value'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: '',
		pointFormat: '<span style="color:{point.color}">\u25CF</span> {series.name}: <b>${point.y:.2f}</b><br/>',
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
	    plotOptions: {
		series: {
			dataLabels: {
				enabled: true,
				format:'${y}'
			}
		}
	   },
            series: [{
                name: 'Sum Value',
                //data: [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
                data: 
                <?php 
                echo    "[".
                        (
                            $noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*275000 + $noResult['400']*700000 + $noResult['1m']*1000000
                            ).", ".
                        (
                            $SixMonths['No_Result']*0 + $SixMonths['35']*17500+ $SixMonths['75']*55000 + $SixMonths['150']*112500 + $SixMonths['150_Plus']*275000 + $SixMonths['400']*700000 + $SixMonths['1m']*1000000 +
                            $noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*275000 + $noResult['400']*700000 + $noResult['1m']*1000000
                            ).", ".
                        (
                            $TwelveMonths['No_Result']*0 + $TwelveMonths['35']*17500+ $TwelveMonths['75']*55000 + $TwelveMonths['150']*112500 + $TwelveMonths['150_Plus']*275000 + $TwelveMonths['400']*700000 + $TwelveMonths['1m']*1000000 +
                            $SixMonths['No_Result']*0 + $SixMonths['35']*17500+ $SixMonths['75']*55000 + $SixMonths['150']*112500 + $SixMonths['150_Plus']*275000 + $SixMonths['400']*700000 + $SixMonths['1m']*1000000 +
                            $noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*275000 + $noResult['400']*700000 + $noResult['1m']*1000000

                            ).", ".
                        (
                            $Longer['No_Result']*0 + $Longer['35']*17500+ $Longer['75']*55000 + $Longer['150']*112500 + $Longer['150_Plus']*275000 + $Longer['400']*700000 + $Longer['1m']*1000000 +
                            $TwelveMonths['No_Result']*0 + $TwelveMonths['35']*17500+ $TwelveMonths['75']*55000 + $TwelveMonths['150']*112500 + $TwelveMonths['150_Plus']*275000 + $TwelveMonths['400']*700000 + $TwelveMonths['1m']*1000000 +
                            $SixMonths['No_Result']*0 + $SixMonths['35']*17500+ $SixMonths['75']*55000 + $SixMonths['150']*112500 + $SixMonths['150_Plus']*275000 + $SixMonths['400']*700000 + $SixMonths['1m']*1000000 +
                            $noResult['No_Result']*0 + $noResult['35']*17500+ $noResult['75']*55000 + $noResult['150']*112500 + $noResult['150_Plus']*275000 + $noResult['400']*700000 + $noResult['1m']*1000000
                        )."]";
                ?>
            }]
        });
    });
</script>
<script type="text/javascript">
        
$(function () {
    $('#campappsbysizeandtime').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            categories: [
                'No Result',
                '0-35k',
                '35-75k',
                '75-150k',
                '150k -400k',
                '400k - 1M',
                '1M +']
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Count'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.1f}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
series: [   {
                name: 'No Timeline',
              
                data: <?php echo  "[".$noResult['No_Result'].", ".$noResult['35'].", ".$noResult['75'].", ".$noResult['150'].", ".$noResult['150_Plus'].", ".$noResult['400'].", ".$noResult['1m']."]"; ?>
            },

            {
                name: 'Within 6 Months',
              
                data: <?php echo  "[".$SixMonths['No_Result'].", ".$SixMonths['35'].", ".$SixMonths['75'].", ".$SixMonths['150'].", ".$SixMonths['150_Plus'].", ".$SixMonths['400'].", ".$SixMonths['1m']."]"; ?>
            }, 

            {
                name: '6-12 Months',
                
                data: <?php echo  "[".$TwelveMonths['No_Result'].", ".$TwelveMonths['35'].", ".$TwelveMonths['75'].", ".$TwelveMonths['150'].", ".$TwelveMonths['150_Plus'].", ".$TwelveMonths['400'].", ".$TwelveMonths['1m']."]"; ?>
            }, {
                name: 'Greater than 12 Months',
                
                data: <?php echo  "[".$Longer['No_Result'].", ".$Longer['35'].", ".$Longer['75'].", ".$Longer['150'].", ".$Longer['150_Plus'].", ".$Longer['400'].", ".$Longer['1m']."]"; ?>
            }]
    });
});
</script>

<script type="text/javascript">
    $(function () {
    var chart;
    
    $(document).ready(function () {
        
        // Build the chart
        $('#appsbymaxvaluepie').highcharts({
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '<b>{point.percentage:.1f}%</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true
                    },
                    showInLegend: true
                }
            },
            series: [{
                type: 'pie',
                name: '',
                data: [
                    ['No Result', <?php echo $noResult['No_Result']+$SixMonths['No_Result']+$TwelveMonths['No_Result']+$Longer['No_Result'] ?>],
                    ['0-35k', <?php echo $noResult['35']+$SixMonths['35']+$TwelveMonths['35']+$Longer['35'] ?>],
                    ['35k - 75k', <?php echo $noResult['75']+$SixMonths['75']+$TwelveMonths['75']+$Longer['75'] ?>],
                    ['75k-150k', <?php echo $noResult['150']+$SixMonths['150']+$TwelveMonths['150']+$Longer['150'] ?>],
                    ['150k - 400k', <?php echo $noResult['150_Plus']+$SixMonths['150_Plus']+$TwelveMonths['150_Plus']+$Longer['150_Plus'] ?>],
                    ['400k - 1m', <?php echo $noResult['400']+$SixMonths['400']+$TwelveMonths['400']+$Longer['400'] ?>],
                    ['1m +', <?php echo $noResult['1m']+$SixMonths['1m']+$TwelveMonths['1m']+$Longer['1m'] ?>],
                ]
            }]
        });
    });
    
});
</script>
<script type="text/javascript">
$(function () {
        $('#appsbymaxvaluebar').highcharts({
            chart: {
                type: 'bar'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                categories: ['No Result','0-35', '35-75', '75-150', '150-400','400-1m','1m +'],
                title: {
                    text: null
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Count',
                    align: 'high'
                },/*
                labels: {
                    overflow: 'justify'
                }*/
            },
            tooltip: {
                valueSuffix: ''
            },
            plotOptions: {
                bar: {
                    dataLabels: {
                        enabled: true
                    }
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -40,
                y: 100,
                floating: true,
                borderWidth: 1,
                backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor || '#FFFFFF'),
                shadow: true
            },
            credits: {
                enabled: false
            },
            series: [{
               name: 'Opportunities',
               data: [<?php echo 
               ($noResult['No_Result']+$SixMonths['No_Result']+$TwelveMonths['No_Result']+$Longer['No_Result']).", ".
               ($noResult['35']+$SixMonths['35']+$TwelveMonths['35']+$Longer['35']).", ".
               ($noResult['75']+$SixMonths['75']+$TwelveMonths['75']+$Longer['75']).", ".
               ($noResult['150']+$SixMonths['150']+$TwelveMonths['150']+$Longer['150']).", ".
               ($noResult['400']+$SixMonths['400']+$TwelveMonths['400']+$Longer['400']).", ".
               ($noResult['1m']+$SixMonths['1m']+$TwelveMonths['1m']+$Longer['1m'])
               ?>]
              
<?php //echo ($TwelveMonths['35']*17500+ $TwelveMonths['75']*55000 + $TwelveMonths['150']*112500 + $TwelveMonths['150_Plus']*200000 + $SixMonths['35']*17500+ $SixMonths['75']*55000 + $SixMonths['150']*112500 + $SixMonths['150_Plus']*200000);?>
            }]
        });
    });

</script>
