<html>
<head></head>
<body>
<?php

include 'credentials.php';

$range = $_POST['range'];
//$result = "three";
$campaign = $_POST['campaign'];
//$campaign = "e18dfc25-4ea0-e206-c8ac-5241df36a9a1','597c267c-d4f3-b9dd-f62b-5241e0c85d67";
$salesreps = $_POST['salesreps'];
//$salesreps = "fa2601d1-4910-6ad4-a2ed-5273b993185a','11c21dc4-2129-d88a-8955-524d8e73a367','146b7358-6afc-da16-efdb-5241de426e7c','1358fd0a-2077-d090-f602-5272b27f9ebe','1da663f5-e39d-6645-87c4-5241e7df115d','1ac031af-b233-599c-4d55-524c62a560f4','2bf326c3-ecab-ec51-09b2-524c4e1a0c37','22214f36-db8c-753c-7058-5272d36e2214','2e80798f-e383-2522-1c7f-524dc5b4858e','33f6f3e7-4621-006a-569c-5294eb6eebf9','35c1a178-2cde-a05a-0af1-5277b3ca085c','3980573f-61d8-691b-3fbd-524c4f6525bc','358bd89d-0112-1146-6c64-528ba2a71a06','413511c7-541f-069e-a337-5272cd66401f','482841a2-1b80-feff-0ff6-5241dfdea64a','4a42fd7e-8a26-2278-bf35-528e7c8c9c75','56301c43-8d8d-e606-5787-524c50e3fa95','6b6132f6-318f-a68a-d46b-526a8849a73b','6fbb7e54-1e4b-66cf-4a09-524dd5bcd55f','74daf1e4-e070-0cf9-785d-524c57b2eae9','7e43580d-ec7d-42a2-bee9-526ac3eb5b5c','7ef9aaa6-c2f6-e478-c1fc-524c50ac4689','8c3518e3-caea-7c8d-20d2-524c52810ca3','8caba917-27a1-721f-dd10-524c4219b2dc','8b9eccf3-233a-f098-1fef-524c51718cb1','8f076a4f-096b-7a3f-27ee-524c5312f191','a203e163-ffb4-c48c-a272-5241e8915f53','a497df3a-8f33-5f07-cf2d-5241e8875bbf','a8564a88-bf1c-da43-d8ea-524c4f1f5f23','395c0a07-ee77-2110-2834-524c532a0ad9','107c0f17-96b5-4fac-3372-52727c6f669e','9a9ff139-5c20-114c-0865-524c6de82f0f','afc834c1-194d-df5e-b1be-529524986b5e','b0ea8b13-9223-f74a-e68d-5269841db1fa','b4ddfb93-d314-18c9-76a8-524c501d463c','b0ee0255-abed-22d0-73f7-52698b6322ce','bd7c84d4-dc40-8b4f-abb2-524ee1f3a063','bdf3dbf0-8fb8-39e7-78a0-5293c6d212a6','bb840576-52e0-fd33-202e-524c4f41d939','bfd0c332-37ea-8353-6d71-524c187e67cb','c5a6bb23-b033-e95d-3069-524c7204ceb5','c21132ba-9c86-a410-55b8-524c70910681','cb32dafd-cf6f-0d48-303c-524c67a63570','c3cc86a2-f947-d7a3-b35e-524c4d91b5e5','b499cf8e-283e-f834-9e66-524c52b36811','d0def585-8ad4-cb13-e88a-524c51d7ad6e','cc7c0560-7300-5d1d-a82a-52a247ab06be','d726ee64-162c-aff7-a9fb-5241e8df7a7c','d09f553d-d18e-5713-bbe1-526985dd017c','d1224898-1c12-0144-8cc7-524c55396658','dcaf51f7-9990-7503-8cb7-5241e704733a";
$sqlStart = $_POST['sqlStart'];
//$sqlStart = "";
$sqlEnd = $_POST['sqlEnd'];
//$sqlEnd = "";

//var_dump($campaign);
//echo "<br/>";
//echo($salesreps);
//echo "<br/>";
// Original PHP code by Chirp Internet: www.chirp.com.au
  // Please acknowledge use of this code by including this header.

  function cleanData(&$str)
  {
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
    if(preg_match("/^0/", $str) || preg_match("/^\+?\d{8,}$/", $str) || preg_match("/^\d{4}.\d{1,2}.\d{1,2}/", $str)) {
      $str = "'$str";
    }
  }

  // filename for download
  $filename = "app_data_" . date('Ymd') . ".xls";

  header("Content-Disposition: attachment; filename=\"$filename\"");
  header("Content-Type: application/vnd.ms-excel");
$week_start = date("Y-m-d H:i:s",strtotime('monday this week'));
  $app_filter = '';
  if($range == 'this' || $range == '')
  {
	$app_filter = "AND (Month(atc_appointments.appointment_date) = Month(curdate()) AND Year(atc_appointments.appointment_date) = Year(curdate()))";
  }
  else if($range == 'week')
 {
     $call_filter = "AND (atc_appointments.appointment_date >= Date('".$week_start."'))";
 }
  else if ($range == 'three')
  {
	$app_filter = "AND (Month(atc_appointments.appointment_date) >= Month(Date_Sub(curdate(),interval 3 month)) AND Year(atc_appointments.appointment_date) >= Year(Date_Sub(curdate(),interval 3 month)))
					AND (Month(atc_appointments.appointment_date) <= Month(curdate()) AND Year(atc_appointments.appointment_date) <= Year(curdate()))";
  }
  else if ($range == 'last')
  {
	$app_filter = "AND (Month(atc_appointments.appointment_date) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(atc_appointments.appointment_date) = Year(Date_Sub(curdate(),interval 1 month)))";
  }
  else
  {
	$app_filter = "AND (atc_appointments.appointment_date > date('".$sqlStart."') or '' = '".$sqlStart."')
                        AND (atc_appointments.appointment_date <= date('".$sqlEnd."') or '' = '".$sqlEnd."')";
  }

  $app_query = "SELECT DISTINCT appointment_number AS 'Appointment Number',appointment_status AS 'Status',appointment_date AS 'Date',appointment_place AS 'Format'
                    ,atc_appointments.description AS 'Notes',sales_rep_feedback AS 'Sales Feedback'
                    ,concat(rep.first_name,' ',rep.last_name) as 'Sales Rep',accounts.name as 'Account Name'
                    ,concat(con.first_name,' ',con.last_name) as 'Contact',con.title AS 'Title',con.phone_other AS 'Direct Phone',con.phone_work AS 'Office Phone'
                    ,contact_email As 'Email',con.primary_address_street AS 'Street',con.primary_address_city AS 'City'
                    ,atc_appointments_cstm.appointment_result_c AS 'Timeline', atc_appointments.opportunity_amount as 'Opportunity Amount'
                    ,con.primary_address_state AS 'State',con.primary_address_postalcode AS 'Postal Code',con.primary_address_country AS 'Country'
                    ,concat(ise.first_name, ' ',ise.last_name) As ISE
                    ,concat(accman.first_name, ' ', accman.last_name) As 'Account Manager'
                FROM atc_appointments INNER JOIN atc_isscampaigns_atc_appointments_c ca

                    ON ca.atc_isscampaigns_atc_appointmentsatc_appointments_idb = atc_appointments.id
            LEFT JOIN atc_clients_atc_isscampaigns_c cc
            ON cc.atc_clients_atc_isscampaignsatc_isscampaigns_idb = ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida
            LEFT JOIN atc_clients c ON c.id = cc.atc_clients_atc_isscampaignsatc_clients_ida
                    INNER JOIN prospectlists_atc_appointments_1_c ta
                    ON ta.prospectlists_atc_appointments_1atc_appointments_idb = atc_appointments.id
                INNER JOIN prospect_lists tl
                    ON tl.id = ta.prospectlists_atc_appointments_1prospectlists_ida
                LEFT JOIN users accman ON tl.assigned_user_id = accman.id
                LEFT JOIN atc_clientsalesreps_atc_appointments_c sa
                    ON sa.atc_clientsalesreps_atc_appointmentsatc_appointments_idb = atc_appointments.id
                left JOIN atc_clientsalesreps rep
                    ON rep.id = sa.atc_clientsalesreps_atc_appointmentsatc_clientsalesreps_ida and sa.deleted = 0 
                INNER JOIN accounts_atc_appointments_1_c acc
                    ON acc.accounts_atc_appointments_1atc_appointments_idb = atc_appointments.id
                INNER JOIN accounts
                    ON accounts.id = acc.accounts_atc_appointments_1accounts_ida
                INNER JOIN atc_appointments_contacts_c ac
                    ON ac.atc_appointments_contactsatc_appointments_idb = atc_appointments.id
                INNER JOIN contacts con
                    ON ac.atc_appointments_contactscontacts_ida = con.id
                LEFT JOIN atc_appointments_cstm
                    ON atc_appointments_cstm.id_c = atc_appointments.id
                LEFT JOIN users ise ON ise.id = atc_appointments.assigned_user_id
                WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".implode("','",$campaign)."')".$salesrepfilter.$app_filter." ORDER BY appointment_date";
             /* $app_query = "SELECT DISTINCT appointment_number AS 'Appointment Number',appointment_status AS 'Status',appointment_date AS 'Date',appointment_place AS 'Format'
                    ,atc_appointments.description AS 'Notes',sales_rep_feedback AS 'Sales Feedback'
                    ,concat(rep.first_name,' ',rep.last_name) as 'Sales Rep',accounts.name as 'Account Name'
                    ,concat(con.first_name,' ',con.last_name) as 'Contact',con.title AS 'Title',con.phone_other AS 'Direct Phone',con.phone_work AS 'Office Phone'
                    ,contact_email As 'Email',con.primary_address_street AS 'Street',con.primary_address_city AS 'City'
          ,atc_appointments_cstm.appointment_result_c AS 'Result'
                    ,con.primary_address_state AS 'State',con.primary_address_postalcode AS 'Postal Code',con.primary_address_country AS 'Country'
          ,concat(ise.first_name, ' ',ise.last_name) As ISE
          ,concat(accman.first_name, ' ', accman.last_name) As 'Account Manager'
          ,concat(accdir.first_name, ' ', accdir.last_name) As 'Account Director'
                FROM atc_appointments INNER JOIN atc_isscampaigns_atc_appointments_c ca
                    ON ca.atc_isscampaigns_atc_appointmentsatc_appointments_idb = atc_appointments.id
        LEFT JOIN atc_clients_atc_isscampaigns_c cc
          ON cc.atc_clients_atc_isscampaignsatc_isscampaigns_idb = ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida
        LEFT JOIN atc_clients c ON c.id = cc.atc_clients_atc_isscampaignsatc_clients_ida
        LEFT JOIN users accdir ON accdir.id = c.assigned_user_id
                INNER JOIN prospectlists_atc_appointments_1_c ta
                    ON ta.prospectlists_atc_appointments_1atc_appointments_idb = atc_appointments.id
        INNER JOIN prospect_lists tl
          ON tl.id = ta.prospectlists_atc_appointments_1prospectlists_ida
        LEFT JOIN users accman ON tl.assigned_user_id = accman.id
                INNER JOIN atc_clientsalesreps_atc_appointments_c sa
                    ON sa.atc_clientsalesreps_atc_appointmentsatc_appointments_idb = atc_appointments.id
                INNER JOIN atc_clientsalesreps rep
                    ON rep.id = sa.atc_clientsalesreps_atc_appointmentsatc_clientsalesreps_ida
                INNER JOIN accounts_atc_appointments_1_c acc
                    ON acc.accounts_atc_appointments_1atc_appointments_idb = atc_appointments.id
                INNER JOIN accounts
                    ON accounts.id = acc.accounts_atc_appointments_1accounts_ida
                INNER JOIN atc_appointments_contacts_c ac
                    ON ac.atc_appointments_contactsatc_appointments_idb = atc_appointments.id
                INNER JOIN contacts con
                    ON ac.atc_appointments_contactscontacts_ida = con.id
                LEFT JOIN atc_appointments_cstm
                    ON atc_appointments_cstm.id_c = atc_appointments.id
        LEFT JOIN users ise ON ise.id = atc_appointments.assigned_user_id
                WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".$campaign."')
                    AND sa.atc_clientsalesreps_atc_appointmentsatc_clientsalesreps_ida IN('".$salesreps."')".
            $app_filter." ORDER BY appointment_date"; */

/*
$logfile = 'X:\www\issales_portal\portal_log.txt';
// Open the file to get existing content
$x = '';
//foreach($_POST as $key=>$value){
//	$x .= "$key: $value\n";
//}
$currentlog = file_get_contents($logfile);
// Append a new person to the file
$currentlog = $app_query."\n";
$currentlog = $x;
// Write the contents back to the file
file_put_contents($logfile, $currentlog);
*/

 $result = mysqli_query($con,$app_query);
  //echo $app_query."<br/>";
  //echo $con->error;

  $flag = false;
  while($row = mysqli_fetch_assoc($result)) {
    if(!$flag) {
      // display field/column names as first row
      echo implode("&#9;", array_keys($row)) . "<br/>";
      $flag = true;
    }
    //array_walk($row, 'cleanData');
    echo implode("&#9;", array_values($row)) . "<br/>";
  }
  exit;
?>
</body>
</html>
