<?php
/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2014 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2014 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    ##VERSION##, ##DATE##
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('America/New_York');

/** Include PHPExcel */
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';
/*
After doing some test, I've got these results benchmarked
for writing to Excel2007:

	Number of rows	Seconds to generate
	200				3
	500				4
	1000			6
	2000			12
	4000			36
	8000			64
	15000			465

*/
require_once 'credentials.php';
require_once "labelvalues.php";

$range = $_POST['range'];
//$range = "three";
$campaign = $_POST['campaign'];
//$campaign = "e18dfc25-4ea0-e206-c8ac-5241df36a9a1','597c267c-d4f3-b9dd-f62b-5241e0c85d67";
$salesrepfilter = $_POST['salesreps'];
//$salesreps = "fa2601d1-4910-6ad4-a2ed-5273b993185a','11c21dc4-2129-d88a-8955-524d8e73a367','146b7358-6afc-da16-efdb-5241de426e7c','1358fd0a-2077-d090-f602-5272b27f9ebe','1da663f5-e39d-6645-87c4-5241e7df115d','1ac031af-b233-599c-4d55-524c62a560f4','2bf326c3-ecab-ec51-09b2-524c4e1a0c37','22214f36-db8c-753c-7058-5272d36e2214','2e80798f-e383-2522-1c7f-524dc5b4858e','33f6f3e7-4621-006a-569c-5294eb6eebf9','35c1a178-2cde-a05a-0af1-5277b3ca085c','3980573f-61d8-691b-3fbd-524c4f6525bc','358bd89d-0112-1146-6c64-528ba2a71a06','413511c7-541f-069e-a337-5272cd66401f','482841a2-1b80-feff-0ff6-5241dfdea64a','4a42fd7e-8a26-2278-bf35-528e7c8c9c75','56301c43-8d8d-e606-5787-524c50e3fa95','6b6132f6-318f-a68a-d46b-526a8849a73b','6fbb7e54-1e4b-66cf-4a09-524dd5bcd55f','74daf1e4-e070-0cf9-785d-524c57b2eae9','7e43580d-ec7d-42a2-bee9-526ac3eb5b5c','7ef9aaa6-c2f6-e478-c1fc-524c50ac4689','8c3518e3-caea-7c8d-20d2-524c52810ca3','8caba917-27a1-721f-dd10-524c4219b2dc','8b9eccf3-233a-f098-1fef-524c51718cb1','8f076a4f-096b-7a3f-27ee-524c5312f191','a203e163-ffb4-c48c-a272-5241e8915f53','a497df3a-8f33-5f07-cf2d-5241e8875bbf','a8564a88-bf1c-da43-d8ea-524c4f1f5f23','395c0a07-ee77-2110-2834-524c532a0ad9','107c0f17-96b5-4fac-3372-52727c6f669e','9a9ff139-5c20-114c-0865-524c6de82f0f','afc834c1-194d-df5e-b1be-529524986b5e','b0ea8b13-9223-f74a-e68d-5269841db1fa','b4ddfb93-d314-18c9-76a8-524c501d463c','b0ee0255-abed-22d0-73f7-52698b6322ce','bd7c84d4-dc40-8b4f-abb2-524ee1f3a063','bdf3dbf0-8fb8-39e7-78a0-5293c6d212a6','bb840576-52e0-fd33-202e-524c4f41d939','bfd0c332-37ea-8353-6d71-524c187e67cb','c5a6bb23-b033-e95d-3069-524c7204ceb5','c21132ba-9c86-a410-55b8-524c70910681','cb32dafd-cf6f-0d48-303c-524c67a63570','c3cc86a2-f947-d7a3-b35e-524c4d91b5e5','b499cf8e-283e-f834-9e66-524c52b36811','d0def585-8ad4-cb13-e88a-524c51d7ad6e','cc7c0560-7300-5d1d-a82a-52a247ab06be','d726ee64-162c-aff7-a9fb-5241e8df7a7c','d09f553d-d18e-5713-bbe1-526985dd017c','d1224898-1c12-0144-8cc7-524c55396658','dcaf51f7-9990-7503-8cb7-5241e704733a";
$sqlStart = $_POST['sqlStart'];
//$sqlStart = "";
$sqlEnd = $_POST['sqlEnd'];
//$sqlEnd = "";

  function cleanData(&$str)
  {
    $str = preg_replace("/\t/", "\\t", $str);
    $str = preg_replace("/\r?\n/", "\\n", $str);
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
    if(preg_match("/^0/", $str) || preg_match("/^\+?\d{8,}$/", $str) || preg_match("/^\d{4}.\d{1,2}.\d{1,2}/", $str)) {
      $str = "'$str";
    }
  }

$week_start = date("Y-m-d H:i:s",strtotime('monday this week'));
  $app_filter = '';
  if($range == 'this' || $range == '')
  {
	$app_filter = "AND (Month(atc_appointments.appointment_date) = Month(curdate()) AND Year(atc_appointments.appointment_date) = Year(curdate()))";
  }
  else if($range == 'week')
 {
     $call_filter = "AND (atc_appointments.appointment_date >= Date('".$week_start."'))";
 }
  else if ($range == 'three')
  {
	$app_filter = "AND (Month(atc_appointments.appointment_date) >= Month(Date_Sub(curdate(),interval 3 month)) AND Year(atc_appointments.appointment_date) >= Year(Date_Sub(curdate(),interval 3 month)))
					AND (Month(atc_appointments.appointment_date) <= Month(curdate()) AND Year(atc_appointments.appointment_date) <= Year(curdate()))";
  }
  else if ($range == 'last')
  {
	$app_filter = "AND (Month(atc_appointments.appointment_date) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(atc_appointments.appointment_date) = Year(Date_Sub(curdate(),interval 1 month)))";
  }
  else
  {
	$app_filter = "AND (atc_appointments.appointment_date > date('".$sqlStart."') or '' = '".$sqlStart."')
                        AND (atc_appointments.appointment_date <= date('".$sqlEnd."') or '' = '".$sqlEnd."')";
  }
     
  $app_query = "SELECT DISTINCT appointment_number AS 'appointment_number',
  								appointment_status AS 'status',
  								appointment_date AS 'date',
  								appointment_place AS 'format',
                  atc_appointments.description AS 'notes',
                  sales_rep_feedback AS 'sales_feedback',
                  concat(rep.first_name,' ',rep.last_name) as 'sales_rep',
                  accounts.name as 'account_name',
                  concat(con.first_name,' ',con.last_name) as 'contact',
                  con.title AS 'title',
                  con.phone_other AS 'direct_phone',
                  con.phone_work AS 'office_phone',
                  contact_email As 'email',
                  con.primary_address_street AS 'street',
                  con.primary_address_city AS 'city',
                  atc_appointments_cstm.appointment_result_c AS 'timeline', 
                  atc_appointments.opportunity_amount as 'opportunity_amount',
                  con.primary_address_state AS 'state',
                  con.primary_address_postalcode AS 'postal_code',
                  con.primary_address_country AS 'country',
					       concat(ise.first_name, ' ',ise.last_name) As 'ise',
                 concat(accman.first_name, ' ', accman.last_name) As 'account_manager',
                 concat(adu.first_name, ' ',adu.last_name) As 'account_director',
                 atc_appointments.date_entered as 'date_created',
                 atc_appointments.date_modified as 'date_modified',
                 cac.campaign_email_and_password_c as 'distrubutor'
                FROM atc_appointments 
                INNER JOIN atc_isscampaigns_atc_appointments_c ca ON ca.atc_isscampaigns_atc_appointmentsatc_appointments_idb = atc_appointments.id AND ca.deleted = 0
                INNER JOIN atc_isscampaigns_cstm cac ON ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida = cac.id_c
		            LEFT JOIN atc_clients_atc_isscampaigns_c cc ON cc.atc_clients_atc_isscampaignsatc_isscampaigns_idb = ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida and cc.deleted = 0
		            LEFT JOIN atc_clients c ON c.id = cc.atc_clients_atc_isscampaignsatc_clients_ida
                INNER JOIN prospectlists_atc_appointments_1_c ta ON ta.prospectlists_atc_appointments_1atc_appointments_idb = atc_appointments.id and ta.deleted = 0
				        INNER JOIN prospect_lists tl ON tl.id = ta.prospectlists_atc_appointments_1prospectlists_ida
				        LEFT JOIN users accman ON tl.assigned_user_id = accman.id 
                LEFT JOIN atc_clientsalesreps_atc_appointments_c sa ON sa.atc_clientsalesreps_atc_appointmentsatc_appointments_idb = atc_appointments.id and sa.deleted = 0
                LEFT JOIN atc_clientsalesreps rep ON rep.id = sa.atc_clientsalesreps_atc_appointmentsatc_clientsalesreps_ida
                INNER JOIN accounts_atc_appointments_1_c acc ON acc.accounts_atc_appointments_1atc_appointments_idb = atc_appointments.id and acc.deleted = 0
                INNER JOIN accounts ON accounts.id = acc.accounts_atc_appointments_1accounts_ida
                INNER JOIN atc_appointments_contacts_c ac ON ac.atc_appointments_contactsatc_appointments_idb = atc_appointments.id and ac.deleted = 0
                INNER JOIN contacts con ON ac.atc_appointments_contactscontacts_ida = con.id
                LEFT JOIN atc_appointments_cstm ON atc_appointments_cstm.id_c = atc_appointments.id
				        LEFT JOIN users ise ON ise.id = atc_appointments.assigned_user_id
                LEFT JOIN users_atc_isscampaigns_1_c ad on ad.users_atc_isscampaigns_1atc_isscampaigns_idb = cac.id_c and ad.deleted = 0
                LEFT JOIN users adu on adu.id = ad.users_atc_isscampaigns_1users_ida ".
                //"WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".implode("','",$campaign)."') ".$salesrepfilter." ".$app_filter." ORDER BY appointment_date;";
                "WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".$campaign."') ".$salesrepfilter." ".$app_filter." ORDER BY appointment_date;";


$result = mysqli_query($con,$app_query); 
  //echo $app_query."<br/>";
  //echo $con->error;

$UTC = new DateTimeZone("UTC");
$newTZ = new DateTimeZone("America/New_York");

// Create new PHPExcel object
//echo date('H:i:s') , " Create new PHPExcel object" , EOL;
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Inside Sales")
							 ->setLastModifiedBy("Inside Sales")
							 ->setTitle("Appointments Output")
							 ->setSubject("Appointments Output")
							 ->setDescription("Inside Sales Appointments Output Document.")
							 ->setKeywords("")
							 ->setCategory("Appointments");


// Create a first sheet
//echo date('H:i:s') , " Add data" , EOL;
$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->setCellValue('A1', "Status");
$objPHPExcel->getActiveSheet()->setCellValue('B1', "Date EST");
$objPHPExcel->getActiveSheet()->setCellValue('C1', "Notes");
$objPHPExcel->getActiveSheet()->setCellValue('D1', "Timeline");
$objPHPExcel->getActiveSheet()->setCellValue('E1', "Opportunity Amount");
$objPHPExcel->getActiveSheet()->setCellValue('F1', "Sales Rep");
$objPHPExcel->getActiveSheet()->setCellValue('G1', "Sales Feedback");
$objPHPExcel->getActiveSheet()->setCellValue('H1', "Format");
$objPHPExcel->getActiveSheet()->setCellValue('I1', "Account Name");
$objPHPExcel->getActiveSheet()->setCellValue('J1', "Contact");
$objPHPExcel->getActiveSheet()->setCellValue('K1', "Title");
$objPHPExcel->getActiveSheet()->setCellValue('L1', "Direct Phone");
$objPHPExcel->getActiveSheet()->setCellValue('M1', "Office Phone");
$objPHPExcel->getActiveSheet()->setCellValue('N1', "Email");
$objPHPExcel->getActiveSheet()->setCellValue('O1', "Street");
$objPHPExcel->getActiveSheet()->setCellValue('P1', "City");
$objPHPExcel->getActiveSheet()->setCellValue('Q1', "State");
$objPHPExcel->getActiveSheet()->setCellValue('R1', "Postal Code");
$objPHPExcel->getActiveSheet()->setCellValue('S1', "Country");
$objPHPExcel->getActiveSheet()->setCellValue('T1', "ISE");
$objPHPExcel->getActiveSheet()->setCellValue('U1', "Account Manager");
$objPHPExcel->getActiveSheet()->setCellValue('V1', "Account Director");
$objPHPExcel->getActiveSheet()->setCellValue('V1', "Distrubutor");
$objPHPExcel->getActiveSheet()->setCellValue('X1', "Date Created");
$objPHPExcel->getActiveSheet()->setCellValue('Y1', "Date Modified");
// Freeze panes
$objPHPExcel->getActiveSheet()->freezePane('A2');
// Rows to repeat at top
$objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);
$i = 2;
while($row = mysqli_fetch_assoc($result)) {
  if($row['status'] != 'Cancelled'){
  $date = new DateTime($row['date'], $UTC);
  $date->setTimezone($newTZ);
  $createddate = new DateTime($row['date_created'], $UTC);
  $createddate->setTimezone($newTZ);
  $modifieddate = new DateTime($row['date_modified'], $UTC);
  $modifieddate->setTimezone($newTZ);
  $objPHPExcel->getActiveSheet()
                                  ->setCellValue('A' . $i, $appointment_status_labels[$row['status']])
                                  ->setCellValue('B' . $i, $date->format('Y-m-d H:iA'))
                                  ->setCellValue('C' . $i, $row['notes'])
                                  ->setCellValue('D' . $i, $opportunity_timeline_labels[$row['timeline']])
                                  ->setCellValue('E' . $i, $opportunity_amount_labels[$row['opportunity_amount']])
                                  ->setCellValue('F' . $i, $row['sales_rep'])
                                  ->setCellValue('G' . $i, $row['sales_feedback'])
                                  ->setCellValue('H' . $i, $row['format'])
                                  ->setCellValue('I' . $i, $row['account_name'])
                                  ->setCellValue('J' . $i, $row['contact'])
                                  ->setCellValue('K' . $i, $row['title'])
                                  ->setCellValue('L' . $i, $row['direct_phone'])
                                  ->setCellValue('M' . $i, $row['office_phone'])
                                  ->setCellValue('N' . $i, $row['email'])
                                  ->setCellValue('O' . $i, $row['street'])
                                  ->setCellValue('P' . $i, $row['city'])
                                  ->setCellValue('Q' . $i, $row['state'])
                                  ->setCellValue('R' . $i, $row['postal_code'])
                                  ->setCellValue('S' . $i, $row['country'])
                                  ->setCellValue('T' . $i, $row['ise'])
                                  ->setCellValue('U' . $i, $row['account_manager'])
                                  ->setCellValue('V' . $i, $row['account_director'])
                                  ->setCellValue('W' . $i, $row['distrubutor'])
                                  ->setCellValue('X' . $i, $createddate->format('Y-m-d H:iA'))
                                  ->setCellValue('Y' . $i, $modifieddate->format('Y-m-d H:iA'));
  //$objPHPExcel->getActiveSheet()->getStyle('C'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_XLSX22);

  $i ++;
  }
}/*

  //debugging variables.
  $objPHPExcel->getActiveSheet()
                                  ->setCellValue('A2', $app_query)
                                  ->setCellValue('A3', $campaign)
                                  ->setCellValue('A4', $salesrepfilter)
                                  ->setCellValue('A5', $app_filter);

  //$objPHPExcel->getActiveSheet()->getStyle('C'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_XLSX22);
*/

//$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
//$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()
    ->getStyle('A1:Y1')
    ->getFill()
    ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setARGB('FF808080');

$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(100);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(100);

$objPHPExcel->getActiveSheet()->getStyle('C1:C'.$objPHPExcel->getActiveSheet()->getHighestRow())->getAlignment()->setWrapText(true); 
$objPHPExcel->getActiveSheet()->getStyle('G1:G'.$objPHPExcel->getActiveSheet()->getHighestRow())->getAlignment()->setWrapText(true); 

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setAutoSize(true);

$objPHPExcel->getActiveSheet()->setTitle("Appointments");



//sets second page!
//sets new index
$objPHPExcel->createSheet(1);
$objPHPExcel->setActiveSheetIndex(1);

$objPHPExcel->getActiveSheet()->setCellValue('A1', "Status");
$objPHPExcel->getActiveSheet()->setCellValue('B1', "Date EST");
$objPHPExcel->getActiveSheet()->setCellValue('C1', "Notes");
$objPHPExcel->getActiveSheet()->setCellValue('D1', "Timeline");
$objPHPExcel->getActiveSheet()->setCellValue('E1', "Opportunity Amount");
$objPHPExcel->getActiveSheet()->setCellValue('F1', "Sales Rep");
$objPHPExcel->getActiveSheet()->setCellValue('G1', "Sales Feedback");
$objPHPExcel->getActiveSheet()->setCellValue('H1', "Format");
$objPHPExcel->getActiveSheet()->setCellValue('I1', "Account Name");
$objPHPExcel->getActiveSheet()->setCellValue('J1', "Contact");
$objPHPExcel->getActiveSheet()->setCellValue('K1', "Title");
$objPHPExcel->getActiveSheet()->setCellValue('L1', "Direct Phone");
$objPHPExcel->getActiveSheet()->setCellValue('M1', "Office Phone");
$objPHPExcel->getActiveSheet()->setCellValue('N1', "Email");
$objPHPExcel->getActiveSheet()->setCellValue('O1', "Street");
$objPHPExcel->getActiveSheet()->setCellValue('P1', "City");
$objPHPExcel->getActiveSheet()->setCellValue('Q1', "State");
$objPHPExcel->getActiveSheet()->setCellValue('R1', "Postal Code");
$objPHPExcel->getActiveSheet()->setCellValue('S1', "Country");
$objPHPExcel->getActiveSheet()->setCellValue('T1', "ISE");
$objPHPExcel->getActiveSheet()->setCellValue('U1', "Account Manager");
$objPHPExcel->getActiveSheet()->setCellValue('V1', "Account Director");
$objPHPExcel->getActiveSheet()->setCellValue('V1', "Distrubutor");
$objPHPExcel->getActiveSheet()->setCellValue('X1', "Date Created");
$objPHPExcel->getActiveSheet()->setCellValue('Y1', "Date Modified");
// Freeze panes
$objPHPExcel->getActiveSheet()->freezePane('A2');
// Rows to repeat at top
$objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);
unset($result);
$result = mysqli_query($con,$app_query); 
$i = 2;
/*
while($row = mysqli_fetch_assoc($result)) {
  if($row['status'] == "Cancelled"){
  $date = new DateTime($row['date'], $UTC);
  $date->setTimezone($newTZ);
  $createddate = new DateTime($row['date_created'], $UTC);
  $createddate->setTimezone($newTZ);
  $modifieddate = new DateTime($row['date_modified'], $UTC);
  $modifieddate->setTimezone($newTZ);
  $objPHPExcel->getActiveSheet()
                                  ->setCellValue('A' . $i, $appointment_status_labels[$row['status']])
                                  ->setCellValue('B' . $i, $date->format('Y-m-d H:iA'))
                                  ->setCellValue('C' . $i, $row['notes'])
                                  ->setCellValue('D' . $i, $opportunity_timeline_labels[$row['timeline']])
                                  ->setCellValue('E' . $i, $opportunity_amount_labels[$row['opportunity_amount']])
                                  ->setCellValue('F' . $i, $row['sales_rep'])
                                  ->setCellValue('G' . $i, $row['sales_feedback'])
                                  ->setCellValue('H' . $i, $row['format'])
                                  ->setCellValue('I' . $i, $row['account_name'])
                                  ->setCellValue('J' . $i, $row['contact'])
                                  ->setCellValue('K' . $i, $row['title'])
                                  ->setCellValue('L' . $i, $row['direct_phone'])
                                  ->setCellValue('M' . $i, $row['office_phone'])
                                  ->setCellValue('N' . $i, $row['email'])
                                  ->setCellValue('O' . $i, $row['street'])
                                  ->setCellValue('P' . $i, $row['city'])
                                  ->setCellValue('Q' . $i, $row['state'])
                                  ->setCellValue('R' . $i, $row['postal_code'])
                                  ->setCellValue('S' . $i, $row['country'])
                                  ->setCellValue('T' . $i, $row['ise'])
                                  ->setCellValue('U' . $i, $row['account_manager'])
                                  ->setCellValue('V' . $i, $row['account_director'])
                                  ->setCellValue('W' . $i, $row['distrubutor'])
                                  ->setCellValue('X' . $i, $createddate->format('Y-m-d H:iA'))
                                  ->setCellValue('Y' . $i, $modifieddate->format('Y-m-d H:iA'));
  //$objPHPExcel->getActiveSheet()->getStyle('C'.$i)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_DATE_XLSX22);

  $i ++;
  }
}
*/
//$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
//$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()
    ->getStyle('A1:Y1')
    ->getFill()
    ->setFillType(PHPExcel_Style_Fill::FILL_SOLID)
    ->getStartColor()
    ->setARGB('FF808080');

$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(100);
$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(100);

$objPHPExcel->getActiveSheet()->getStyle('C1:C'.$objPHPExcel->getActiveSheet()->getHighestRow())->getAlignment()->setWrapText(true); 
$objPHPExcel->getActiveSheet()->getStyle('G1:G'.$objPHPExcel->getActiveSheet()->getHighestRow())->getAlignment()->setWrapText(true); 

$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setAutoSize(true);
$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setAutoSize(true);


$objPHPExcel->getActiveSheet()->setTitle("Cancellations");
// Save Excel 2007 file
//echo date('H:i:s') , " Write to Excel2007 format" , EOL;
//$callStartTime = microtime(true);
//
//so it opens o th
$objPHPExcel->setActiveSheetIndex(0);
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
ob_end_clean();
// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="iss_appointments.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0


//$objWriter->save(str_replace('.php', '.xlsx', __FILE__));
$objWriter->save("php://output");

//$callEndTime = microtime(true);
//$callTime = $callEndTime - $callStartTime;

//echo date('H:i:s') , " File written to " , str_replace('.php', '.xlsx', pathinfo(__FILE__, PATHINFO_BASENAME)) , EOL;
//echo 'Call time to write Workbook was ' , sprintf('%.4f',$callTime) , " seconds" , EOL;
// Echo memory usage
//echo date('H:i:s') , ' Current memory usage: ' , (memory_get_usage(true) / 1024 / 1024) , " MB" , EOL;


// Echo memory peak usage
//echo date('H:i:s') , " Peak memory usage: " , (memory_get_peak_usage(true) / 1024 / 1024) , " MB" , EOL;

// Echo done
//echo date('H:i:s') , " Done writing file" , EOL;
//echo 'File has been created in ' , getcwd() , EOL;


/*
// Redirect output to a client’s web browser (Excel2007)
	
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="inside_sales_appointments.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
exit;*/
//echo "success";
?>
