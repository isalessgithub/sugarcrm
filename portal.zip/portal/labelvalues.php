<?php


$opportunity_amount_labels=array(
  '' => '',
  'No_Result' => 'No Result',
  '35' => '0 - 35',
  '75' => '35-75',
  '150' => '75-150',
  '150_Plus' => '150-400',
  '400' => '400 - 1 Mil',
  '1m' => '1 Mil +'
);

$opportunity_timeline_labels = array(
  '' => '',
  'NoResult' => 'No Result',
  'SixMonths' => 'Within 6 Months',
  'TwelveMonths' => 'Within 12 Months',
  'Longer' => 'Greater than 12 Months',
); 


$appointment_status_labels = array(
  '' => '',
  'Attended' => 'Attended',
  'Attended_Policy' => 'Attended',
  'Cancelled' => 'Cancelled',
  'Accepted' => 'Accepted',
  'Confirmed' => 'Confirmed',
  'Reschedule' => 'Reschedule'
);