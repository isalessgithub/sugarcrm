var $overlay_wrapper;
var $overlay_panel;

function show_overlay() {
    if ( !$overlay_wrapper ) append_overlay();
    $overlay_wrapper.fadeIn(700);
}

function hide_overlay() {
    $overlay_wrapper.fadeOut(500);
}

function append_overlay($inputText) {
    $row = document.getElementById($inputText);
    $overlay_wrapper = $('<div id="overlay"></div>').appendTo( $('BODY') );
    $overlay_panel = $('<div id="overlay-panel" ></div>').appendTo( $overlay_wrapper );


    $overlay_panel.html( '<table style="white-space: pre-line;"><tr>'+'<td width="50%"><table class="table table-striped" border="1"><tr><th width="60%">Notes</th>'+
    '<th width="40%">Sales Rep Feedback</th>'+
    '<tr><td>'+$('#'+$inputText).find('#description').text()+'</td>'+
    '<td>'+$('#'+$inputText).find('#feedback').text()+'</td></tr></table></td>'+
    '<td width="50%"><table class="table table-striped" border="1">'+
    '<tr><th>Title</th><td>'+$('#'+$inputText).find('#title').text()+'</td>'+
    '<th>Street</th><td>'+$('#'+$inputText).find('#street').text()+'</td></tr>'+
    '<tr><th>Direct Phone</th><td>'+$('#'+$inputText).find('#dphone').text()+'</td>'+
    '<th>City</th><td>'+$('#'+$inputText).find('#city').text()+'</td></tr>'+
    '<tr><th>Office Phone</th><td>'+$('#'+$inputText).find('#ophone').text()+'</td>'+
    '<th>State</th><td>'+$('#'+$inputText).find('#state').text()+'</td></tr>'+
    '<tr><th>Email Address</th><td>'+$('#'+$inputText).find('#email').text()+'</td>'+
    '<th>Postal Code</th><td>'+$('#'+$inputText).find('#zip').text()+'</td></tr>'+
    '<tr><th>ISE</th><td>'+$('#'+$inputText).find('#ise').text()+'</td>'+
    '<th>Country</th><td>'+$('#'+$inputText).find('#country').text()+'</td></tr>'+
    '<tr><th>Account Manager</th><td>'+$('#'+$inputText).find('#manager').text()+'</td>'+
    '<th>Date Created</th><td>'+$('#'+$inputText).find('#date_entered').text()+'</td></tr>'+
    //'<tr><th>Account Director</th><td>'+$('#'+$inputText).find('#director').text()+'</td></tr>'+
    '</table></td>'+
    '</tr></table>'+
    '<a href="#" class="hide-overlay">Close Record</a>');

    attach_overlay_events();
}

function attach_overlay_events() {
    $('A.hide-overlay', $overlay_wrapper).click( function(ev) {
        ev.preventDefault();
        hide_overlay();
    });
}

$(function() {
    $('A.show-overlay').click( function(ev) {
        ev.preventDefault();
        show_overlay();
    });
});
