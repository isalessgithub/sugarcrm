<div style="position: relative;">
    <div style="display:inline;font-size: 10px; line-height: 16px;">*Click an Appointment Number to see more details</div>
    <div style="display:inline;float:right;top: 0;"><a onclick="ExportExcel()" >Export to Excel</a></div>
    <table class="table table-striped" style="background: url(images/white-bg.png);">
        <thead>
            <tr>
                <th>Number</th><th>Status</th><th>Format</th><th>Date</th><th>Account</th><th>Sales Rep</th><th>Contact Name</th><th>Opportunity Timeline</th><th>Opportunity Amount</th>
            </tr>
        </thead>
    <?php 
        require_once "labelvalues.php";
        $app_filter = '';
        $month_three = date("Y-m-", strtotime("-3 months")).'01';
        $week_start = date("Y-m-d H:i:s",strtotime('monday this week'));
        if($range == 'all')
        {
         $app_filter = " ";
     }
     else if($range == 'week')
     {
         $app_filter = "AND (atc_appointments.appointment_date >= Date('".$week_start."'))";
     }
     else if($range == 'this')
     {
         $app_filter = "AND (Month(atc_appointments.appointment_date) = Month(curdate()) AND Year(atc_appointments.appointment_date) = Year(curdate()))";
     }
     else if ($range == 'three')
     {
         $app_filter = "AND (atc_appointments.appointment_date >= Date('".$month_three."')) AND (atc_appointments.appointment_date <= Last_Day(curdate()))";
     }
     else if ($range == 'last')
     {
         $app_filter = "AND (Month(atc_appointments.appointment_date) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(atc_appointments.appointment_date) = Year(Date_Sub(curdate(),interval 1 month)))";
     }
     else
     {
         $app_filter = "AND (atc_appointments.appointment_date > date('".$sqlStart."') or '' = '".$sqlStart."')
         AND (atc_appointments.appointment_date <= date('".$sqlEnd."') or '' = '".$sqlEnd."')";
     }



     $app_agg_query = "SELECT SUM(CASE WHEN appointment_status = 'Cancelled' THEN 1 ELSE 0 END) AS num_cancelled
     , SUM(CASE WHEN appointment_status = 'Attended' OR appointment_status = 'Attended_Policy' THEN 1 ELSE 0 END) AS num_attended
     , SUM(CASE WHEN appointment_status = 'Accepted' THEN 1 ELSE 0 END) AS num_accepted
     , SUM(CASE WHEN appointment_status = 'Reschedule' THEN 1 ELSE 0 END) AS num_rescheduled
     , SUM(CASE WHEN appointment_status = 'Confirmed' THEN 1 ELSE 0 END) AS num_confirmed
     , SUM(CASE WHEN appointment_status IN ('Attended','Attended_Policy','Cancelled','Accepted','Reschedule','Confirmed') THEN 1 ELSE 0 END) AS num_appointments
     , SUM(CASE WHEN Month(atc_appointments.appointment_date) = Month(curdate()) AND Year(atc_appointments.appointment_date) = Year(curdate()) THEN 1 ELSE 0 END) As num_month
     , SUM(CASE WHEN Month(atc_appointments.appointment_date) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(atc_appointments.appointment_date) = Year(Date_Sub(curdate(),interval 1 month)) THEN 1 ELSE 0 END) As num_last
     , Date_Format(Max(atc_appointments.appointment_date),'%Y%m') AS MaxDate
     , Date_Format(Min(atc_appointments.appointment_date),'%Y%m') AS MinDate
     , camp.name AS CampName
     FROM atc_appointments INNER JOIN atc_isscampaigns_atc_appointments_c ca
     ON ca.atc_isscampaigns_atc_appointmentsatc_appointments_idb = atc_appointments.id
     INNER JOIN atc_isscampaigns camp
     ON camp.id = ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida
     LEFT JOIN prospectlists_atc_appointments_1_c ta
     ON ta.prospectlists_atc_appointments_1atc_appointments_idb = atc_appointments.id
     LEFT JOIN atc_clientsalesreps_atc_appointments_c sa ON sa.atc_clientsalesreps_atc_appointmentsatc_appointments_idb = atc_appointments.id
     WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".implode("','",$campaign)."')
     and atc_appointments.deleted = 0
     and ca.deleted = 0
     and camp.deleted = 0
     and ta.deleted = 0
     and sa.deleted = 0 ".$salesrepfilter.$app_filter." GROUP BY camp.name";

     $app_agg_result = mysqli_query($con,$app_agg_query);

     $app_agg_array = array();

     $num_appointments = 0;
     $num_app_month = 0;
     $num_app_last = 0;
     $num_app_max = 0;
     $num_app_min = 999999;

     while ($row = mysqli_fetch_array($app_agg_result))
     {
         $app_agg_array[] = array($row['num_accepted'],$row['num_rescheduled'],$row['num_attended'],$row['num_cancelled'],$row['num_confirmed'],$row['CampName']);
         $num_appointments += $row['num_appointments'];
         $num_app_month += $row['num_month'];
         $num_app_last += $row['num_last'];
         $num_app_max = ($row['MaxDate'] > $num_app_max ? $row['MaxDate'] : $num_app_max);
         $num_app_min = ($row['MinDate'] < $num_app_min ? $row['MaxDate'] : $num_app_min);
     }
     $num_avg_apps = $num_appointments/($num_app_max-$num_app_min+1);

     $app_held_query = "SELECT SUM(CASE WHEN appointment_status = 'Attended' OR appointment_status = 'Attended_Policy' OR appointment_status = 'Confirmed' THEN 1 ELSE 0 END) AS num_held
     , SUM(CASE WHEN cstm.appointment_result_c = 'NoResult' or cstm.appointment_result_c = '' THEN 1 ELSE 0 END) AS NumNo
     , SUM(CASE WHEN cstm.appointment_result_c = 'SixMonths' THEN 1 ELSE 0 END) AS NumSix
     , SUM(CASE WHEN cstm.appointment_result_c = 'TwelveMonths' THEN 1 ELSE 0 END) AS NumTwelve
     , SUM(CASE WHEN cstm.appointment_result_c = 'Longer' THEN 1 ELSE 0 END) AS NumLonger
     , SUM(CASE WHEN Month(atc_appointments.appointment_date) = Month(curdate()) AND Year(atc_appointments.appointment_date) = Year(curdate()) AND (appointment_status = 'Attended' OR appointment_status = 'Attended_Policy')  THEN 1 ELSE 0 END) As num_month
     , SUM(CASE WHEN Month(atc_appointments.appointment_date) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(atc_appointments.appointment_date) = Year(Date_Sub(curdate(),interval 1 month)) AND (appointment_status = 'Attended' OR appointment_status = 'Attended_Policy')  THEN 1 ELSE 0 END) As num_last
     , SUM(CASE WHEN appointment_status = 'Attended' OR appointment_status = 'Attended_Policy' OR appointment_status = 'Confirmed'   THEN 1 ELSE 0 END)/(PERIOD_DIFF(Date_Format(Max(atc_appointments.appointment_date),'%Y%m'),Date_Format(Min(atc_appointments.appointment_date),'%Y%m'))+1) As AvgHeld
     FROM atc_appointments INNER JOIN atc_isscampaigns_atc_appointments_c ca
     ON ca.atc_isscampaigns_atc_appointmentsatc_appointments_idb = atc_appointments.id
     LEFT JOIN prospectlists_atc_appointments_1_c ta
     ON ta.prospectlists_atc_appointments_1atc_appointments_idb = atc_appointments.id
     LEFT JOIN atc_clientsalesreps_atc_appointments_c sa
     ON sa.atc_clientsalesreps_atc_appointmentsatc_appointments_idb = atc_appointments.id
     LEFT JOIN atc_appointments_cstm cstm
     ON cstm.id_c = atc_appointments.id
     WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".implode("','",$campaign)."')".$app_filter.$salesrepfilter.
     "and atc_appointments.deleted = 0
     and ca.deleted = 0
     and ta.deleted = 0
     and sa.deleted = 0
     AND (appointment_status = 'Attended' OR appointment_status ='Attended_Policy' OR appointment_status = 'Confirmed');";
     $app_held_result = mysqli_query($con,$app_held_query);

     $row = mysqli_fetch_array($app_held_result);
     $app_cht_results = array(intval($row['NumNo']),intval($row['NumSix']),intval($row['NumTwelve']),intval($row['NumLonger']));
     $num_held = $row['num_held'];
     $num_held_month = $row['num_month'];
     $num_held_last = $row['num_last'];
     $num_held_avg = $row['AvgHeld'];

     $app_query = "SELECT distinct 
     appointment_number,
     appointment_status,
     atc_appointments.id,
     appointment_date,
     appointment_place,
     atc_appointments.description,
     atc_appointments.date_entered,
     atc_appointments.opportunity_amount,
     sales_rep_feedback,
     rep.first_name as rep_first,
     rep.last_name as rep_last,
     accounts.name as acc_name,
     con.first_name as con_first,
     con.last_name as con_last,
     con.title,
     con.phone_other,
     con.phone_work,
     contact_email,
     con.primary_address_street,
     con.primary_address_city,
     atc_appointments_cstm.appointment_result_c,
     con.primary_address_state,
     con.primary_address_postalcode,
     con.primary_address_country,
     concat(ise.first_name, ' ',ise.last_name) As ISE,
     concat(accman.first_name, ' ', accman.last_name) As Acc_Man
     FROM atc_appointments INNER JOIN atc_isscampaigns_atc_appointments_c ca
     ON ca.atc_isscampaigns_atc_appointmentsatc_appointments_idb = atc_appointments.id and ca.deleted = 0
     LEFT JOIN atc_clients_atc_isscampaigns_c cc 
     ON cc.atc_clients_atc_isscampaignsatc_isscampaigns_idb = ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida
     LEFT JOIN atc_clients c ON c.id = cc.atc_clients_atc_isscampaignsatc_clients_ida and c.deleted = 0
     LEFT JOIN prospectlists_atc_appointments_1_c ta
     ON ta.prospectlists_atc_appointments_1atc_appointments_idb = atc_appointments.id and ta.deleted = 0
     LEFT JOIN prospect_lists tl
     ON tl.id = ta.prospectlists_atc_appointments_1prospectlists_ida and tl.deleted = 0
     LEFT JOIN users accman ON tl.assigned_user_id = accman.id and accman.deleted = 0
     LEFT JOIN atc_clientsalesreps_atc_appointments_c sa
     ON sa.atc_clientsalesreps_atc_appointmentsatc_appointments_idb = atc_appointments.id and sa.deleted = 0
     LEFT JOIN atc_clientsalesreps rep
     ON rep.id = sa.atc_clientsalesreps_atc_appointmentsatc_clientsalesreps_ida and rep.deleted = 0
     INNER JOIN accounts_atc_appointments_1_c acc
     ON acc.accounts_atc_appointments_1atc_appointments_idb = atc_appointments.id and acc.deleted = 0
     LEFT JOIN accounts
     ON accounts.id = acc.accounts_atc_appointments_1accounts_ida and acc.deleted = 0
     LEFT JOIN atc_appointments_contacts_c ac
     ON ac.atc_appointments_contactsatc_appointments_idb = atc_appointments.id and ac.deleted = 0
     LEFT JOIN contacts con
     ON ac.atc_appointments_contactscontacts_ida = con.id and con.deleted = 0
     LEFT JOIN atc_appointments_cstm
     ON atc_appointments_cstm.id_c = atc_appointments.id
     LEFT JOIN users ise ON ise.id = atc_appointments.assigned_user_id
     WHERE ca.atc_isscampaigns_atc_appointmentsatc_isscampaigns_ida IN('".implode("','",$campaign)."')".$salesrepfilter.
     $app_filter." ORDER BY appointment_date";
     $app_result = mysqli_query($con,$app_query);

                    $UTC = new DateTimeZone("UTC");
                    $newTZ = new DateTimeZone("America/New_York");
                
     //echo $app_query;
     while ($row = mysqli_fetch_array($app_result))
     {
            /*$color = 'rgb(192,197,37);';
            switch($row['appointment_status']) {
                case 'Reschedule':
                    $color = 'red;';
                    break;
                case 'Attended':
                    $color = 'green;';
                    break;
                }*/

                if ($row['appointment_status'] != 'Cancelled')
                {
                    
                    echo "<tr id='".$row['id']."'>";
                    echo "<td id='description' style='display: none;'><pre>";
                    echo $row['description']."</pre></td>";
                    echo "<td id='feedback' style='display: none;'><pre>";
                    echo $row['sales_rep_feedback']."</pre></td>";
                    echo "<td id='title' style='display: none;'>";
                    echo $row['title']."</td>";
                    echo "<td id='dphone' style='display: none;'>";
                    echo $row['phone_other']."</td>";
                    echo "<td id='ophone' style='display: none;'>";
                    echo $row['phone_work']."</td>";
                    echo "<td id='email' style='display: none;'>";
                    echo $row['contact_email']."</td>";
                    echo "<td id='street' style='display: none;'>";
                    echo $row['primary_address_street']."</td>";
                    echo "<td id='city' style='display: none;'>";
                    echo $row['primary_address_city']."</td>";
                    echo "<td id='state' style='display: none;'>";
                    echo $row['primary_address_state']."</td>";
                    echo "<td id='zip' style='display: none;'>";
                    echo $row['primary_address_postalcode']."</td>";
                    echo "<td id='country' style='display: none;'>";
                    echo $row['primary_address_country']."</td>";
                    echo "<td id='ise' style='display: none;'>";
                    echo $row['ISE']."</td>";
                    echo "<td id='manager' style='display: none;'>";
                    echo $row['Acc_Man']."</td>";
                    //echo "<td id='director' style='display: none;'>";
                    //echo $row['Acc_Dir']."</td>";
                    echo "<td id='date_entered' style='display: none;'>";
                    //echo date_format(date_create($row['date_entered']),"m-d-Y h:iA")."</td>";
                    $dateentered = new DateTime($row['date_entered'], $UTC);
                    $dateentered->setTimezone($newTZ);
                    echo $dateentered->format('m-d-Y h:iA');
                    //echo date_format(date_sub(date_create($row['date_entered']),date_interval_create_from_date_string("5 hour")),"m-d-Y h:iA");
                    echo "<td>";
                    echo "<a href='#' class='show-overlay' onclick=\"append_overlay('".$row['id']."')\">".$row['appointment_number']."</a>";
                //echo "</td><td style='color: ".$color."'>";
                    echo "</td><td>";
                    echo $appointment_status_labels[$row['appointment_status']];
                    echo "</td><td>";
                    echo $row['appointment_place'];
                    echo "</td><td>";
                    $appdate = new DateTime($row['appointment_date'], $UTC);
                    $appdate->setTimezone($newTZ);
                    echo $appdate->format('m-d-Y h:iA');
                    //echo date_format(date_sub(date_create($row['appointment_date']),date_interval_create_from_date_string("5 hour")),"m-d-Y h:iA");
                    echo "</td><td>";
                    echo $row['acc_name'];
                    echo "</td><td>";
                    echo $row['rep_first'].' '.$row['rep_last'];
                    echo "</td><td>";
                    echo $row['con_first'].' '.$row['con_last'];
                    echo "</td><td>";
       
                $resultoptions = Array(
                    "NoResult" => "No Timeline",
                    "SixMonths" => "< 6 Months",
                    "TwelveMonths" => "6-12 Months",
                    "Longer" => "> 12 Months"
                    );
                if ($row['appointment_status'] == 'Attended' || $row['appointment_status'] == 'Attended_Policy' || $row['appointment_status'] == 'Confirmed')
                {  
                    echo $resultoptions[$row['appointment_result_c']];
                }
                echo "</td><td>";
                $amountoptions = Array(
                    "" => "",
                    "No_Result" => "No Result",
                    "35" => "0-35k",
                    "75" => "35-75k",
                    "150" => "75-150k",
                    "150_Plus" => "150k-400k",
                    "400" => "400k-1M",
                    "1m" => "1M +"
                    );
                if  ($row['appointment_status'] == 'Attended' || $row['appointment_status'] == 'Attended_Policy' || $row['appointment_status'] == 'Confirmed')
                {  
                    echo $amountoptions[$row['opportunity_amount']];
                }


                echo "</td></tr>";
            }
        }

        ?>


    </table>

</div>
