<?php
$num_calls = 0;
$call_outcome = array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);

$call_filter = '';

if($range == 'this' or $range == ''){
    $call_filter = "AND (Month(calls.date_modified) = Month(curdate()) AND Year(calls.date_modified) = Year(curdate()))";
}
 else if($range == 'week')
 {
     $call_filter = "AND (calls.date_modified >= Date('".$week_start."'))";
 }
else if ($range == 'three'){
    $call_filter = "AND (calls.date_modified >= Date('".$month_three."')) AND (calls.date_modified <= Last_Day(curdate()))";
}
else if ($range == 'last'){
    $call_filter = "AND (Month(calls.date_modified) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(calls.date_modified) = Year(Date_Sub(curdate(),interval 1 month)))";
}
else
{
    $call_filter = "AND (calls.date_modified > date('".$sqlStart."') or '' = '".$sqlStart."') AND (calls.date_modified <= date('".$sqlEnd."') or '' = '".$sqlEnd."')";
}
 $call_agg_query = "SELECT SUM(CASE WHEN calls_cstm.call_outcome_c = 'Call' THEN 1 ELSE 0 END) As num_call
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Not Interested' THEN 1 ELSE 0 END) As num_not_interested
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Left company' THEN 1 ELSE 0 END) As num_left
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Admin Blocking' THEN 1 ELSE 0 END) As num_admin
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Lead Generated' THEN 1 ELSE 0 END) As num_lead
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Long term call back' THEN 1 ELSE 0 END) As num_long_call
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Hot call back' THEN 1 ELSE 0 END) As num_hot
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Contact_Sales_Rep' THEN 1 ELSE 0 END) As Contact_Sales_Rep
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Referral To' THEN 1 ELSE 0 END) As num_ref_to
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Reschedule' THEN 1 ELSE 0 END) As num_reschedule
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Cancelled' THEN 1 ELSE 0 END) As num_cancelled
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'WrongContact' THEN 1 ELSE 0 END) As num_wrong
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'WrongNumber' THEN 1 ELSE 0 END) As num_number
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Booked Colleague' THEN 1 ELSE 0 END) As num_colleague
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Invite_Sent' THEN 1 ELSE 0 END) As invite_sent
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'suggestedcolleague' THEN 1 ELSE 0 END) As num_suggested
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Existing_Customer' THEN 1 ELSE 0 END) As num_existing
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Does_Not_Qualify' THEN 1 ELSE 0 END) As num_dnq
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Outsourced' THEN 1 ELSE 0 END) As num_outsourced
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'EmailandVM1' THEN 1 ELSE 0 END) As email_vm1
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'EmailandVM2' THEN 1 ELSE 0 END) As email_vm2
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'EmailandVM3' THEN 1 ELSE 0 END) As email_vm3
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'EmailandVM4' THEN 1 ELSE 0 END) As email_vm4
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'New_Contact' THEN 1 ELSE 0 END) As new_contact
 , SUM(CASE WHEN calls_cstm.call_outcome_c = 'Short_Term_Call_Back' THEN 1 ELSE 0 END) As short_term_call_back
 , SUM(CASE WHEN calls_cstm.call_outcome_c <> '' THEN 1 ELSE 0 END) As total_calls
 , SUM(CASE WHEN Month(calls.date_entered) = Month(curdate()) AND Year(calls.date_entered) = Year(curdate()) THEN 1 ELSE 0 END) As num_month
 , SUM(CASE WHEN Month(calls.date_entered) = Month(Date_Sub(curdate(),interval 1 month)) AND Year(calls.date_entered) = Year(Date_Sub(curdate(),interval 1 month)) THEN 1 ELSE 0 END) As num_last
 , SUM(CASE WHEN calls_cstm.call_outcome_c <> '' THEN 1 ELSE 0 END)/(PERIOD_DIFF(Date_Format(Max(calls.date_entered),'%Y%m'),Date_Format(Min(calls.date_entered),'%Y%m'))+1) As AvgCalls
 FROM calls INNER JOIN calls_cstm ON calls.id = calls_cstm.id_c
 INNER JOIN atc_isscampaigns_calls_1_c cc
 ON cc.atc_isscampaigns_calls_1calls_idb = calls.id
 WHERE cc.atc_isscampaigns_calls_1atc_isscampaigns_ida IN('".implode("','",$campaign)."')".
 $call_filter.
 "AND calls.date_entered <> ''
 ORDER BY calls.date_entered asc";

$call_agg_result = mysqli_query($con,$call_agg_query);

 $row = mysqli_fetch_array($call_agg_result);
 $call_outcome = array($row['num_call'],$row['num_not_interested'],$row['num_left'],$row['num_admin']
    ,$row['num_lead'],$row['num_long_call'],$row['num_hot'],$row['Contact_Sales_Rep'],$row['num_ref_to'],$row['num_reschedule']
    ,$row['num_cancelled'],$row['num_wrong'],$row['num_number'],$row['num_colleague'],$row['invite_sent'],$row['num_suggested']
    ,$row['num_existing'],$row['num_dnq'],$row['num_outsourced'],$row['email_vm1'],$row['email_vm2'],$row['email_vm3'],$row['email_vm4'],$row['new_contact'],$row['short_term_call_back']);
 $num_calls = $row['total_calls'];
 $num_calls_month = $row['num_month'];
 $num_calls_last = $row['num_last'];
 $avg_calls = $row['AvgCalls'];
 ?>


   
<table width="100%" border="1" style="background: url(images/white-bg.png);" class="table table-striped">
    <thead>
        <tr>
            <th colspan="4" style="text-align: center;">
                Call Activity
            </th>
            <th colspan="4" style="text-align: center;">
                Appointments Set
            </th>
        </tr>
    </thead>
    <tr>
        <td colspan="4" width="50%">
            <div id="ChartCalls" style="width: 475px; height: 300px; background: url(images/white-bg.png);"></div>
        </td>
        <td colspan="4" width="50%">
            <div id="ChartAppSet" style="width: 475px; height: 300px; background: url(images/white-bg.png);"></div>
        </td>
    </tr>
    <tr>
        <td>
            Total Activity
        </td>
        <td>
            <?php echo $num_calls; ?>
        </td>
        <td>
            Monthly Average
        </td>
        <td>
            <?php echo Round($avg_calls,1); ?>
        </td>
        <td>
            Total Appointments
        </td>
        <td>
            <?php echo $num_appointments; ?>
        </td>
        <td>
            Monthly Average
        </td>
        <td>
            <?php echo Round($num_avg_apps,1); ?>
        </td>
    </tr>
    <tr>
        <td>
            Current Month
        </td>
        <td>
            <?php echo $num_calls_month; ?>
        </td>
        <td>
            Previous Month
        </td>
        <td>
            <?php echo $num_calls_last; ?>
        </td>
        <td>
            Current Month
        </td>
        <td>
            <?php echo $num_app_month; ?>
        </td>
        <td>
            Previous Month
        </td>
        <td>
            <?php echo $num_app_last; ?>
        </td>
    </tr>
</table>
<script type='text/javascript'>//<![CDATA[ 
        $(function () {
            $('#ChartAppSet').highcharts({
                chart: {
                    type: 'column'
                },
                title: {
                    text: ''
                },
                xAxis: {
                    categories: ['Accepted','Rescheduled','Attended','Cancelled','Confirmed'],
                //title: {
                //    text: 'Fruit Types'
                //}
                labels: {
                    rotation: -45
                }
            },
            yAxis: {
                title: {
                    text: ''
                }
            },
            series: [
            <?php foreach($app_agg_array as $row)
            {
               echo "{";
               echo "name: '".$row[5]."',";
               echo "data: [".$row[0].",".$row[1].",".$row[2].",".$row[3].",".$row[4]."]";
               echo "},";
           }
           ?>
    		/*{
                name: 'Appointments',
                data: [<?php echo $num_accepted.','.$num_rescheduled.','.$num_attended.','.$num_cancelled.','.$num_confirmed; ?>]
            }*/],
            legend: {
                enabled: false
            }
        });
});
    //]]>  
</script>
    <script type='text/javascript'>//<![CDATA[ 
        $(function () {
            $('#ChartCalls').highcharts({
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false
                },
                title: {
                    text: ''
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: true,
                            color: '#000000',
                            connectorColor: '#000000',
                        format: '<b>{point.name}</b>'//: {point.percentage:.1f} %'
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Activity',
                data: [
                <?php 
                if ($call_outcome[0] > 0) {echo "['Call', ".$call_outcome[0]."],";} 
                if ($call_outcome[1] > 0) {echo "['Not Interested', ".$call_outcome[1]."],";} 
                if ($call_outcome[2] > 0) {echo "['Left company', ".$call_outcome[2]."],";} 
                if ($call_outcome[3] > 0) {echo "['Admin Blocking', ".$call_outcome[3]."],";} 
                if ($call_outcome[4] > 0) {echo "['Lead Generated', ".$call_outcome[4]."],";} 
                if ($call_outcome[5] > 0) {echo "['Long term call back', ".$call_outcome[5]."],";} 
                if ($call_outcome[6] > 0) {echo "['Hot call back', ".$call_outcome[6]."],";} 
                if ($call_outcome[7] > 0) {echo "['Contact Sales Rep', ".$call_outcome[7]."],";} 
                if ($call_outcome[8] > 0) {echo "['Referral To', ".$call_outcome[8]."],";} 
                if ($call_outcome[9] > 0) {echo "['Reschedule', ".$call_outcome[9]."],";} 
                if ($call_outcome[10] > 0) {echo "['Cancelled', ".$call_outcome[10]."],";} 
                if ($call_outcome[11] > 0) {echo "['Wrong Contact', ".$call_outcome[11]."],";} 
                if ($call_outcome[12] > 0) {echo "['Wrong Number', ".$call_outcome[12]."],";} 
                if ($call_outcome[13] > 0) {echo "['Booked Colleague', ".$call_outcome[13]."],";}
                if ($call_outcome[14] > 0) {echo "['Email&Callback', ".$call_outcome[14]."],";} 
                if ($call_outcome[15] > 0) {echo "['Suggested Colleague', ".$call_outcome[15]."],";}
                if ($call_outcome[16] > 0) {echo "['Existing Customer', ".$call_outcome[16]."],";}
                if ($call_outcome[17] > 0) {echo "['Does Not Qualify', ".$call_outcome[17]."],";}
                if ($call_outcome[18] > 0) {echo "['Outsourced', ".$call_outcome[18]."],";} 
                if ($call_outcome[19] > 0) {echo "['Email and VM1', ".$call_outcome[19]."],";} 
                if ($call_outcome[20] > 0) {echo "['Email and VM2', ".$call_outcome[20]."],";} 
                if ($call_outcome[21] > 0) {echo "['Email and VM3', ".$call_outcome[21]."],";} 
                if ($call_outcome[22] > 0) {echo "['Email and VM4', ".$call_outcome[22]."],";}
                if ($call_outcome[23] > 0) {echo "['New Contact', ".$call_outcome[23]."],";}
                if ($call_outcome[24] > 0) {echo "['Short Term Call Back', ".$call_outcome[24]."],";}

                ?>
                ]
            }],
        });
});
    //]]>  
</script>
 
