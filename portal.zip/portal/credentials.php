<?php
//$login_con = mysqli_connect("88425f5257a5603d1b5b79b097a218d9e7b8a1ad.rackspaceclouddb.com","isaless","issugarcrm!","sugarcrm");
$login_con = mysqli_connect("localhost","root","issugarcrm!","issugarcrm");

//$con = mysqli_connect("88425f5257a5603d1b5b79b097a218d9e7b8a1ad.rackspaceclouddb.com","isaless_test","issugarcrm!","sugarcrm_test");
//$con = mysqli_connect("88425f5257a5603d1b5b79b097a218d9e7b8a1ad.rackspaceclouddb.com", "isaless","issugarcrm!","sugarcrm");  
$con = mysqli_connect("localhost","root","issugarcrm!","issugarcrm");
