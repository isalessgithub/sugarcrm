<html>
<link href="theme/Login.css" rel="stylesheet" type="text/css" />
<head>
<title>Client Portal</title>
<script src="//platform.linkedin.com/in.js" type="text/javascript">lang: en_US</script>
<link href="theme/bootstrap.css" rel="stylesheet" />
<script type='text/javascript' src='js/jquery-1.10.2.js'></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
<?php
if (isset($_GET['login']))
{
    if ($_GET['login'] == 'logout')
    {
        session_start();
        session_destroy();
    }
}

session_start();
$errormsg = '';
include 'credentials.php';
if (isset($_POST['loginForm']))
{
	//include 'sugarauth.php';

	if (mysqli_connect_errno())
	{
		$errormsg = "Failed to connect to Database";
	}
	else
	{
		$query = "select password, username, cu.cp_client_users_atc_clientsatc_clients_idb As Client_ID
			from cp_client_users users
			Left join cp_client_users_atc_clients_c cu 
				on cu.cp_client_users_atc_clientscp_client_users_ida = users.id
			where username = '".strtolower($_POST['user'])."' and cu.deleted = 0";
		$result = mysqli_query($login_con,$query);
		$clients = array();
		$password = '';
		$num_rows = 0;
		while ($row = mysqli_fetch_array($result))
		{
			$password = $row['password'];
			$clients[] = $row['Client_ID'];
			$num_rows++;
		}
		mysqli_close($login_con);
		if ($_POST['password'] == $password && $num_rows > 0) 
		{
			//SetSession('portal','insidesales1');
			$_SESSION['client'] = "'" . implode("','", $clients) . "'";
			//Redirect to Report
			//header("Location:/report.php");
			header("Location:report.php");
	
			exit;
		}
		else
		{
			$errormsg = "Username or Password is Incorrect";
		}
	}
}
?>

<div class="Header">
<div class="Logo" style="padding: 5px 0; position: relative;">
<!--<img src="images/iss_logo_white_sm.png" />-->
<img src="http://isaless.com/wp-content/themes/roots/assets/img/logo.png" />
<div style="position: absolute; right: 5px; top: 5px; color: #666; vertical-align: top;">
CALL US: 347-918-4747 | <script type="IN/FollowCompany" data-id="2512818" data-counter="none"></script>
</div>
<div style="position: absolute; right: 5px; bottom: 5px;" class="btn-group">
<a role="button" class="btn btn-default" href="http://isaless.com">Home</a>
                    <a role="button" class="btn btn-default" href="http://isaless.com/services">Service Offerings</a>
                    <a role="button" class="btn btn-default" href="http://isaless.com/about">About Us</a>
                    <a role="button" class="btn btn-default" href="http://isaless.com/blog">Blog</a>
</div>
</div>
</div>
<table width="100%" height="100%">
<tr>
<td>

<table class="TableCenter">
<tr>
<td>
<?php echo "<div style='color: red; text-align: center;'>".$errormsg."</div>"; ?>
<form action="" method="post" name="loginForm">
<table>
<tr>
<td>Username:</td>
<td><input type="text" name="user"/></td>
</tr>
<tr>
<td>Password:</td>
<td><input type="password" name="password" /></td>
</tr>
</table>
<input type="hidden" value="login" name="loginForm" />
<center><input type="submit" value="Login"/></center>
</form>

</td>
</tr>
</table>
</td>
</tr>
</table>

<div style="font-size: 8px; background-color: #164891; position:absolute; width: 100%; bottom: 0px;" >
<div class="Logo" style="padding: 5px 0; position: relative; text-align: center;">
<a style="color: white; text-decoration: none;" href="http://isaless.com/service-offerings/">SERVICE OFFERINGS | </a>
<a style="color: white; text-decoration: none;" href="http://isaless.com/clients/">CLIENTS | </a>
<a style="color: white; text-decoration: none;" href="http://isaless.com/about-us/">ABOUT US | </a>
<a style="color: white; text-decoration: none;" href="http://isaless.com/contact-us/">CONTACT US</a><br/>
</div>
</div>

</body>

</html>
