<?php
session_start();
//include_once 'call.php';
//include 'appointments.php';
//include 'related.php';
//include 'getentry.php';
include 'credentials.php';
// Check connection
if (mysqli_connect_errno())
{
    echo "Failed to connect to Database";
}

$campaign = array();
$salesreps = array();
$startdate = '';
$enddate = '';
$interval = '';
$range = 'all';

if (isset($_POST['dateselect']))
{
    $range = $_POST['dateselect'];
}
if (isset($_POST['startdate']))
{
    $startdate = $_POST['startdate'];
}
if (isset($_POST['enddate']))
{
    $enddate = $_POST['enddate'];
}
if (isset($_POST['period']))
{
    $interval = $_POST['period'];
}
if (isset($_POST['campaigns']))
{
    $campaign = $_POST['campaigns'];
}
if (isset($_POST['salesReps']))
{
    $salesreps = $_POST['salesReps'];
}
if (isset($_POST['toggle']))
{
    $apptoggle = $_POST['apptoggle'] * -1;
}
else if (isset($_POST['apptoggle']))
{
    $apptoggle = $_POST['apptoggle'];
}
else
{
    $apptoggle = 1;
}
$sqlStart = '';
$sqlEnd = '';
if ($startdate != '')
{
    $sqlStart = date('Y/m/d',strtotime($startdate));
}
if ($enddate != '')
{
    $sqlEnd = date('Y/m/d',strtotime($enddate));
}

?>
<html >
<meta charset="utf-8"> 
<link href="theme/Report.css" rel="stylesheet" type="text/css" />
<link href="theme/bootstrap.css" rel="stylesheet" />
<link href="css/smoothness/jquery-ui-1.10.4.custom.css" rel="stylesheet" />
<script type='text/javascript' src='js/jquery-1.10.2.js'></script>
<script type='text/javascript' src='js/jquery-ui-1.10.4.custom.js'></script>
<script src="js/bootstrap.min.js"></script>
<!--<script src="js/highcharts.js"></script>-->
<script src="http://code.highcharts.com/highcharts.js"></script>
<link rel="stylesheet" type="text/css" href="theme/overlay.css" />
<script type="text/javascript" src="js/overlay.js"></script>
<script src="//platform.linkedin.com/in.js" type="text/javascript">lang: en_US</script>

<script>
    $(function() {
        $( "#tabs" ).tabs();
        // Hover states on the static widgets
        $( "#dialog-link, #icons li" ).hover(
            function() {
                $( this ).addClass( "ui-state-hover" );
            },
            function() {
                $( this ).removeClass( "ui-state-hover" );
            }
        );
    });
    </script>
    <style>

    .demoHeaders {
        margin-top: 2em;
    }
    #dialog-link {
        padding: .4em 1em .4em 20px;
        text-decoration: none;
        position: relative;
    }
    #dialog-link span.ui-icon {
        margin: 0 5px 0 0;
        position: absolute;
        left: .2em;
        top: 50%;
        margin-top: -8px;
    }
    #icons {
        margin: 0;
        padding: 0;
    }
    #icons li {
        margin: 2px;
        position: relative;
        padding: 4px 0;
        cursor: pointer;
        float: left;
        list-style: none;
    }
    #icons span.ui-icon {
        float: left;
        margin: 0 4px;
    }
    .fakewindowcontain .ui-widget-overlay {
        position: absolute;
    }
    </style>
<head>
    <title>Client Portal</title>
</head>
<body>
    <div class="Header" style="display:block;height:100px;">
        <div class="Logo" style="padding: 5px 0;">
            <!--<img src="images/iss_logo_white_sm.png" />-->
            <img src="http://isaless.com/wp-content/themes/roots/assets/img/logo.png" />
            <div style="display: inline-block; float:right;right: 5px; top: 5px; color: #666; vertical-align:bottom;font-family: Open Sans;">
                CALL US: 347-918-4747 | 
                <div style="vertical-align:bottom;display:inline;"><script type="IN/FollowCompany" data-id="2512818" data-counter="none"></script></div>
            </div>
            <div style="display:inline-block;right:5px; margin-top:30px; float:right;clear:right;align:right;vertical-align:bottom;">
                <div style="display:inline;" class="btn-group">
                    <a role="button" class="btn btn-default" href="http://isaless.com">Home</a>
                    <a role="button" class="btn btn-default" href="http://isaless.com/services">Service Offerings</a>
                    <a role="button" class="btn btn-default" href="http://isaless.com/about">About Us</a>
                    <a role="button" class="btn btn-default" href="http://isaless.com/blog">Blog</a>
                    <a role="button" style="color:#32C8DE;" class="btn btn-default" href="index.php?login=logout" >Logout</a>
                </div><!--
                <div style="display:inline-block;padding-top:10px;padding-left:10px;">
                    <a style="color: #32C8DE;font-family:Open Sans;font-weight:bold;" href="index.php?login=logout" >Logout</a>
                </div>-->
            </div>
        </div>
    </div>
    <div style="display:block;position:relative;">
        <form style="margin: 0px;" action="report.php" method="post" name="theForm">
            <div class="Logo">
                <div class="filtertitle" style="padding: 5px;"><a id="filtertitle" style="color: #164891;" onclick="toggleFilter()">Hide Filter</a></div>
                <div id="filterbox" class="well" style="margin: 0px;">
                    <table width="100%" style="border-spacing: 5px 0; border-collapse: separate;">
                        <tr>
                            <td style="vertical-align: top;">
                                <label style="color: #164891;" for="startdate">Date Range</label>
                                <select class="form-control" name="dateselect" id="dateselect" value="<?php echo $range; ?>" onchange="validate('startdate')">
                                    <option value ="all">All</option>
                                    <option value="week" <?php if ($range == 'week') echo "Selected"; ?>>This Week</option>
                                    <option value="this" <?php if ($range == 'this') echo "Selected"; ?>>This Month</option>
                                    <option value="last" <?php if ($range == 'last') echo "Selected"; ?>>Last Month</option>
                                    <option value="three"<?php if ($range == 'three') echo "Selected"; ?>>Last Three Months</option>
                                    <option value="range"<?php if ($range == 'range') echo "Selected"; ?>>Date Range</option>
                                </select>
                                <div id="range" class="<?php if(!isset($_POST['dateselect']) OR $range != 'range'){echo "hide";} ?>">
                                    <label style="color: #164891;" for="startdate">Start Date (MM/DD/YYYY)</label>
                                    <input class="form-control" id="startdate" name="startdate" type="text" value="<?php echo $startdate; ?>" onchange="validate('startdate')" />
                                    <label style="color: #164891;" for="enddate">End Date (MM/DD/YYYY)</label>
                                    <input class="form-control" id="enddate" name="enddate" type="text" value="<?php echo $enddate; ?>" onchange="validate('enddate')" />
                                </div>
                            </td>
                            <?php  
                            echo    '<td style="vertical-align: top;"><label style="color: #164891;" for="campaigns">Campaigns</label><br />
                                    <select size="5" class="form-control" name="campaigns[]" id="campaigns" multiple="MULTIPLE"  onchange="'."validate('startdate')".'" >';
                                   $campaign_query = "SELECT distinct atc_isscampaigns.id, name
                                    FROM atc_isscampaigns INNER JOIN atc_clients_atc_isscampaigns_c cc 
                                    ON cc.atc_clients_atc_isscampaignsatc_isscampaigns_idb = atc_isscampaigns.id and cc.deleted = 0 and atc_isscampaigns.deleted = 0
                                    INNER JOIN atc_isscampaigns_cstm ISC ON ISC.id_c = atc_isscampaigns.id
                                    WHERE cc.atc_clients_atc_isscampaignsatc_clients_ida IN (".$_SESSION['client'].")
                                    AND (ISC.campaign_status_c != 'Inactive' OR ISC.campaign_status_c IS NULL)
                                    ORDER BY name";
                                    $camp_result = mysqli_query($con,$campaign_query);

                                    while($row = mysqli_fetch_array($camp_result))
                                    {
                                        if(!isset($_POST['campaigns']) or in_array($row['id'],$campaign))
                                        {
                                            echo "<option value=\"".$row['id']."\" selected>".$row['name']."</option>";
                                            $campaign[] = $row['id'];
                                        }
                                        else
                                        {
                                            echo "<option value=\"".$row['id']."\">".$row['name']."</option>";
                                        }
                                    }


                                echo '</select></td>';

                            ?>
                            
                               </select>
                           </td>
                           <td style="vertical-align: top;">
                            <label style="color: #164891;" for="salesReps">Sales Reps</label><br />
                            <select size="5" class="form-control" name="salesReps[]" multiple="MULTIPLE" id="salesReps" onchange="validate('startdate')" >
                                <?php 


                                $sales_query = "SELECT atc_clientsalesreps.id, first_name, last_name 
                                FROM atc_clientsalesreps INNER JOIN atc_clients_atc_clientsalesreps_c cs 
                                ON cs.atc_clients_atc_clientsalesrepsatc_clientsalesreps_idb = atc_clientsalesreps.id
                                WHERE cs.deleted = 0 and atc_clientsalesreps.deleted = 0 and cs.atc_clients_atc_clientsalesrepsatc_clients_ida IN (".$_SESSION['client'].")
                                ORDER BY last_name";
                                $sales_result = mysqli_query($con,$sales_query);

                                if(!isset($_POST['salesReps']) or in_array('all',$salesreps)){
                                        echo "<option value=\""."all"."\" selected>All</option>";
                                        $salesreps[] = "all";
                                }
                                else{
                                    echo "<option value=\""."all"."\" >All</option>";
                                }
                                while($row = mysqli_fetch_array($sales_result))
                                {
                                    if(in_array($row['id'],$salesreps))
                                    {
                                        echo "<option value=\"".$row['id']."\" selected>".$row['last_name'].", ".$row['first_name']."</option>";
                                        $salesreps[] = $row['id'];
                                    }
                                    else
                                    {
                                        echo "<option value=\"".$row['id']."\" >".$row['last_name'].", ".$row['first_name']."</option>";
                                    }
                                }

                                     $salesrepfilter = "";
                                     if (in_array('all',$salesreps)){
                                        $salesrepfilter = "";
                                     }
                                     else{
                                        $salesrepfilter = " AND sa.atc_clientsalesreps_atc_appointmentsatc_clientsalesreps_ida IN('".implode("','",$salesreps)."') ";
                                     }
                                 ?>
                            </select>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </form>
    </div>
    <div id="tabs" class="Logo">
        <ul>
          <li><a href="#tabs-1">Activity</a></li>
            <li><a href="#tabs-2">Campaign Results</a></li>
            <li><a href="#tabs-3">Appointments</a></li>
        </ul>
        <div id="tabs-3" class="Logo">
              <?php include "ap.php"; ?>
        </div>
        <div id="tabs-1" class="Logo">
           <?php include "activity.php"; ?>
           
        </div>
        <div id="tabs-2" class="Logo">
             <?php include "campaignresults.php"; ?>
        </div>
    </div>
<div style="font-size: 8px; background-color: #164891; width: 100%;" >
    <div class="Logo" style="padding: 5px 0; position: relative; text-align: center;">
        <a style="color: white; text-decoration: none;" href="http://isaless.com/service-offerings/">SERVICE OFFERINGS | </a>
        <a style="color: white; text-decoration: none;" href="http://isaless.com/clients/">CLIENTS | </a>
        <a style="color: white; text-decoration: none;" href="http://isaless.com/about-us/">ABOUT US | </a>
        <a style="color: white; text-decoration: none;" href="http://isaless.com/contact-us/">CONTACT US</a><br/>
    </div>
</div>
<script type="text/javascript">
    function validatedate(inputText)
    {
        var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
  // Match the date format through regular expression
  if(inputText.value.match(dateformat))
  {
        //document.getElementById("startdate").focus();
        inputText.focus();
  //Test which seperator is used '/' or '-'
  var opera1 = inputText.value.split('/');
  var opera2 = inputText.value.split('-');
  lopera1 = opera1.length;
  lopera2 = opera2.length;
  // Extract the string into month, date and year
  if (lopera1>1)
  {
    var pdate = inputText.value.split('/');
}
else if (lopera2>1)
{
    var pdate = inputText.value.split('-');
}
var dd = parseInt(pdate[0]);
var mm  = parseInt(pdate[1]);
var yy = parseInt(pdate[2]);
  // Create list of days of a month [assume there is no leap year by default]
  var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];
  if (mm==1 || mm>2)
  {
    if (dd>ListofDays[mm-1])
    {
        alert('Invalid date format!');
        return false;
    }
}
if (mm==2)
{
    var lyear = false;
    if ( (!(yy % 4) && yy % 100) || !(yy % 400)) 
    {
        lyear = true;
    }
    if ((lyear==false) && (dd>=29))
    {
        alert('Invalid date format!');
        return false;
    }
    if ((lyear==true) && (dd>29))
    {
        alert('Invalid date format!');
        return false;
    }
}
}
else
{
    alert("Invalid date format!");
        //document.getElementById("startdate").select();
        inputText.select();
        return false;
    }
    return true;
}
</script>
<script>
    function validate (dateinput)
    {
        if ((document.getElementById(dateinput).value == '') || validatedate(document.getElementById(dateinput))) 
        {
        //document.getElementById(dateinput).focus();
        document.theForm.submit();
    }

}
</script>
<script>
    function UpdateResult($id,$Result)
    {
     var xmlhttp;
     if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
        xmlhttp.open("POST","ResultUpdate.php",true);
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        xmlhttp.send("appid="+$id+"&result="+$Result);
    }
    else
    {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        xmlhttp.open("POST","ResultUpdate.php",true);
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        xmlhttp.send("appid="+$id+"&result="+$Result);
    }
}
</script>
<script>

    function ExportExcel()
    {
    /*var xmlhttp;
    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
        xmlhttp.open("POST","excel.php",true);
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        xmlhttp.onload = function () {
            // do something to response
            alert(this.responseText);
        };
        xmlhttp.send("range=<?php echo $range; ?>&campaign=<?php echo implode("','",$campaign); ?>&targetlists=<?php echo implode("','",$targetlist); ?>&salesreps=<?php echo implode("','",$salesreps); ?>&sqlStart=<?php echo $sqlStart; ?>&sqlEnd=<?php echo $sqlEnd; ?>");
    }
    else
    {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        xmlhttp.open("POST","excel.php",true);
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        xmlhttp.send("range=<?php echo $range; ?>&campaign=<?php echo implode("','",$campaign); ?>&targetlists=<?php echo implode("','",$targetlist); ?>&salesreps=<?php echo implode("','",$salesreps); ?>&sqlStart=<?php echo $sqlStart; ?>&sqlEnd=<?php echo $sqlEnd; ?>");
    }*/
   //method = "post"; // Set method to post by default if not specified.

    // The rest of this code assumes you are not using a library.
    // It can be made less wordy if you use one.
   
    //range = <?php echo "'".$range."'"; ?>;
    campaigns = <?php echo "'".implode("','",$campaign)."'"; ?>;
    //var camp = <?php echo "'".implode("','",$campaign)."'"; ?>;
    repfilter = <?php  echo "'".$salesrepfilter."'"; ?>;
    sqlstart = <?php echo "'".$sqlStart."'"; ?>;
    sqlend = <?php echo "'".$sqlEnd."'"; ?>;

    //$.post("newexcel.php", {"range" : range, "campaigns" : campaigns, "reps" : reps, "sqlstart" : sqlstart, "sqlend" : sqlend});

    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", "newexcel.php");

    var range = document.createElement("input");
    range.setAttribute("type", "hidden");
    range.setAttribute("name", "range");
    range.setAttribute("value", "<?php echo $range; ?>");
    form.appendChild(range);
    
    var camp = document.createElement("input");
    camp.setAttribute("type", "hidden");
    camp.setAttribute("name", "campaign");
    camp.setAttribute("value", "<?php echo implode("','",$campaign); ?>");
    form.appendChild(camp);
    var reps = document.createElement("input");
    reps.setAttribute("type", "hidden");
    reps.setAttribute("name", "salesreps");
    //reps.setAttribute("value", "<?php echo implode("','",$salesreps); ?>");
    reps.setAttribute("value", repfilter);
    form.appendChild(reps);
    var start = document.createElement("input");
    start.setAttribute("type", "hidden");
    start.setAttribute("name", "sqlStart");
    start.setAttribute("value", "<?php echo $sqlStart; ?>");
    form.appendChild(start);
    var end = document.createElement("input");
    end.setAttribute("type", "hidden");
    end.setAttribute("name", "sqlEnd");
    end.setAttribute("value", "<?php echo $sqlEnd; ?>");
    form.appendChild(end);

    document.body.appendChild(form);
    form.submit();
}
</script>
<script>
    function toggleFilter()
    {
     if (document.getElementById("filterbox").className == "hide well")
     {
      document.getElementById("filterbox").className = "well";
      document.getElementById("filtertitle").innerHTML= "Hide Filter";
  }
  else
  {
      document.getElementById("filterbox").className = "hide well";
      document.getElementById("filtertitle").innerHTML= "Show Filter";
  }
}
</script>
<script>
    function toggleRange($range)
    {
     if ($range == "range")
     {
      document.getElementById("range").className = "";
  }
  else
  {
      document.getElementById("range").className = "hide";
  }
}
</script>
</body>
</html>
