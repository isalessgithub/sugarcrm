<?php
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);

define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

date_default_timezone_set('America/New_York');

/** Include PHPExcel */
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';
$objPHPExcel = new PHPExcel();

// Set document properties
//echo date('H:i:s') , " Set properties" , EOL;
$objPHPExcel->getProperties()->setCreator("Inside Sales")
							 ->setLastModifiedBy("Inside Sales")
							 ->setTitle("Appointments Output")
							 ->setSubject("Appointments Output")
							 ->setDescription("Inside Sales Appointments Output Document.")
							 ->setKeywords("")
							 ->setCategory("Appointments");


// Create a first sheet
//echo date('H:i:s') , " Add data" , EOL;
$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->setCellValue('A1', "Appointment Number");
$objPHPExcel->getActiveSheet()->setCellValue('B1', "Status");
$objPHPExcel->getActiveSheet()->setCellValue('C1', "Date");
$objPHPExcel->getActiveSheet()->setCellValue('D1', "Format");
$objPHPExcel->getActiveSheet()->setCellValue('E1', "Notes");
$objPHPExcel->getActiveSheet()->setCellValue('F1', "Sales Feedback");
$objPHPExcel->getActiveSheet()->setCellValue('G1', "Sales Rep");
$objPHPExcel->getActiveSheet()->setCellValue('H1', "Account Name");
$objPHPExcel->getActiveSheet()->setCellValue('I1', "Contact");
$objPHPExcel->getActiveSheet()->setCellValue('J1', "Title");
$objPHPExcel->getActiveSheet()->setCellValue('K1', "Direct Phone");
$objPHPExcel->getActiveSheet()->setCellValue('L1', "Office Phone");
$objPHPExcel->getActiveSheet()->setCellValue('M1', "Email");
$objPHPExcel->getActiveSheet()->setCellValue('N1', "Street");
$objPHPExcel->getActiveSheet()->setCellValue('O1', "City");
$objPHPExcel->getActiveSheet()->setCellValue('P1', "Timeline");
$objPHPExcel->getActiveSheet()->setCellValue('Q1', "Opportunity Amount");
$objPHPExcel->getActiveSheet()->setCellValue('R1', "State");
$objPHPExcel->getActiveSheet()->setCellValue('S1', "Postal Code");
$objPHPExcel->getActiveSheet()->setCellValue('T1', "Country");
$objPHPExcel->getActiveSheet()->setCellValue('U1', "ISE");
$objPHPExcel->getActiveSheet()->setCellValue('V1', "Account Manager");



// Hide "Phone" and "fax" column
//echo date('H:i:s') , " Hide 'Phone' and 'fax' columns" , EOL;
//$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setVisible(false);
//$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setVisible(false);


// Set outline levels
//echo date('H:i:s') , " Set outline levels" , EOL;
//$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setOutlineLevel(1)
//                                                       ->setVisible(false)
//                                                       ->setCollapsed(true);

// Freeze panes
//echo date('H:i:s') , " Freeze panes" , EOL;
$objPHPExcel->getActiveSheet()->freezePane('A2');


// Rows to repeat at top
//echo date('H:i:s') , " Rows to repeat at top" , EOL;
$objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);


//$i = 42;
    
//while($row = mysqli_fetch_assoc($result)) {
// Add data
for ($i = 2; $i <= 50; $i++) {
	$objPHPExcel->getActiveSheet()
	                              ->setCellValue('A' . $i, "Format $i")
	                              ->setCellValue('B' . $i, "Format $i")
                         	      ->setCellValue('C' . $i, "Format $i")
	                              ->setCellValue('D' . $i, "Format $i")
	                              ->setCellValue('E' . $i, "Notes $i")
	                              ->setCellValue('F' . $i, "Sales Feedback $i")
	                              ->setCellValue('G' . $i, "Sales Rep $i")
	                              ->setCellValue('H' . $i, "Account Name $i")
	                              ->setCellValue('I' . $i, "Contact $i")
	                              ->setCellValue('J' . $i, "Title $i")
	                              ->setCellValue('K' . $i, "Direct Phone $i")
	                              ->setCellValue('L' . $i, "Office Phone $i")
	                              ->setCellValue('M' . $i, "Email $i")
	                              ->setCellValue('N' . $i, "Street $i")
	                              ->setCellValue('O' . $i, "City $i")
	                              ->setCellValue('P' . $i, "Timeline $i")
	                              ->setCellValue('Q' . $i, "Opportunity Amount $i")
	                              ->setCellValue('R' . $i, "State $i")
	                              ->setCellValue('S' . $i, "Postal Code $i")
	                              ->setCellValue('T' . $i, "Country $i")
	                              ->setCellValue('U' . $i, "ISE $i")
	                              ->setCellValue('V' . $i, "Account Manager $i");

}


$objPHPExcel->setActiveSheetIndex(0);

// Save Excel 2007 file
//echo date('H:i:s') , " Write to Excel2007 format" , EOL;
//$callStartTime = microtime(true);
//
// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="iss_appointments.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
//$objWriter->save(str_replace('.php', '.xlsx', __FILE__));
$objWriter->save('php://output');
?>
