<?php

$date = '2013-11-12 16:00:00';
echo "<br />";

echo $date;
echo "<br />";

echo "existing";
echo "<br />";

echo date_format(date_create($date),"m-d-Y h:iA");

echo "<br />";
echo "new";
echo "<br />";

echo date_format(date_sub(date_create($date),date_interval_create_from_date_string("5 hour")),"m-d-Y h:iA");